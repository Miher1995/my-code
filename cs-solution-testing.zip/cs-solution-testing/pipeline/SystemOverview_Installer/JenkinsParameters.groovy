static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sys/SystemOverview.Installer.git' }
static def repoName() { 'SystemOverview.Installer' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Observe.REST.git' }
static def repoName() { 'Observe.REST' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sicc/Base.git' }
static def repoName() { 'Base' }

return this
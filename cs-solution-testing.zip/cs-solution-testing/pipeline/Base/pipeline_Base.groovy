import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2'], description: 'Choice the slave')
        string( name: 'package_output_file_name', defaultValue: 'artifactoryPackages.out', description: 'output file for build')
        string( name: 'inject_version', defaultValue: '1.27.0', description: 'version to be injected')
		string( name: 'attivio_version', defaultValue: '', description: 'generic attivio version for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{

            stage('Remove assemble dir'){
                  steps{
                       script{

                        powershell '''
								if(Test-Path -Path "assemble/")
									{
										echo "Removing assemble folder"
										Remove-Item -Recurse -Force "assemble/*"
									}
                        '''
                    }
                }
            }

            stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )
        stage('Delete directory', {
            steps {
               dir('build') {
                                deleteDir()
                            }
            }
        })
        stage('Repo Checkout on Slave', {
            steps {
                
                script {
                    dir("build/assemble/base") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${env.gitlabBranch as String?:params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        })

        stage('Resolve Dependencies'){
			steps{
                dir("build")
                {
                    script{
					powershell '''echo "${env:gitlabBranch}"
                                  ./assemble/base/scripts/resolve.ps1 -WorkingDirectory "$PWD"
                    '''	
				}
                }
				
			}
		}

        stage('Create output file with CreateArtifactoryPackageRestoreOutputFile script'){
            environment {
                BUILDSYSTEM_HOME="C:/build-farm"
            }

			steps{
                dir("build/assemble/base")
                {
                    script{
					powershell ''' echo "${env.BUILDSYSTEM_HOME}"
                    C:/work/build-farm/tools/Atlassian/CreateArtifactoryPackageRestoreOutputFile.ps1 -OutputFile "artifactoryPackages.out" -PackagesLocation "jars" -FileExtension ".jar"
                    '''	
				}
                }
				
			}
		}

         stage('Create branched version', {
            steps{
                 dir("build/assemble/base") {
                script{
                    powershell '''
                    $branchname = "${env:BRANCH_NAME_Version}"
                    if ("${env:gitlabBranch}")
                    {
                        $branchname = "${env:gitlabBranch}"
                    }
                    
                    $version = "${env:inject_version}"

                    echo $version

                    if (!($branchname -match "^master|release|develop"))
                    {
                    $versionlength = [math]::min( 20, $branchname.length )
            
                    $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                    $version = "$version-$branchname"
                    }
                    $version
                    "env.branchVersion='$version'" | Out-File ".\\variables.groovy" -Encoding ASCII'''

                    powershell '''Get-Content variables.groovy | Foreach-Object{
                    $var = $_.Split(\'=\')
                    New-Variable -Name $var[0] -Value $var[1]
                    }'''
                }

            }
        }
    })


        stage('Load Environment Variables', {
            
                steps {
                    dir("build/assemble/base"){
                script {
                    load "variables.groovy"      
                    powershell '''
                    echo "Branch version is: ${env:branchVersion}"
                    '''              
                    }
                }
            }
            
            }
        )

        
        stage('Prepare Automation scripts for packing', {
            steps{
                dir("build") {
                script{
                    powershell '''
                    $automation_script_path="assemble/automationtests"
                    New-Item -ItemType directory -Path $automation_script_path -Force
                    New-Item -ItemType directory -Path "output" -Force
                    echo "Listing working directory"
                    Get-ChildItem -Recurse -Verbose
                    Write-Host "Listing base tests"
                    Get-ChildItem "assemble/base/tests" -recurse -verbose
                    Write-Host "End listing base tests"
                    Copy-Item "assemble/base/tests" -Destination $automation_script_path -recurse -force -verbose
                    Copy-Item "assemble/base/testdata" -Destination $automation_script_path -recurse -force -verbose

                    Write-Host "List $automation_script_path"
                    Get-ChildItem -Recurse $automation_script_path
                    '''
                     }
                }
            }
        })

            stage('Zip Automation scripts'){
            steps{
                dir("build") {
                script{
                    powershell '''
                        Compress-Archive -Path  "assemble\\automationtests\\*"  "output\\nice-aie_automation-scripts-${env:branchVersion}.zip"   -Update
                    '''
                }
                }
            }
        }

       stage('Zip test data'){
            steps{
                dir("build") {
                script{
                    powershell '''
                        Compress-Archive -Path  "assemble\\base\\testdata\\*"  "output\\testdata.zip"   -Update
                    '''
                }
                }
            }
        }  

            stage('Copy jars to Base Config', {
            steps{
                dir("build") {
                script{
                    powershell '''
                    $NICE_AIE_LIB_OVERRIDE="assemble/base/nice-aie/lib-override/"
                    $JARS_SOURCE_BASE = "jars/Attivio_4x_jars"
                    $BASE_DIR = "Base"

                    Get-ChildItem -Path "$JARS_SOURCE_BASE\\*.jar" -Recurse | Copy-Item -Destination $NICE_AIE_LIB_OVERRIDE


                    if( -Not (Test-Path -Path $BASE_DIR ) )
                    {
                        New-Item -ItemType directory -Path $BASE_DIR
                    }
                    '''
                     }
                }
            }
        })


            stage('Create branched version 2', {
            steps{
                 dir("build/assemble/base") {
                script{
                    powershell '''
                    $branchname = "${env:BRANCH_NAME_Version}"
                    if ("${env:gitlabBranch}")
                    {
                        $branchname = "${env:gitlabBranch}"
                    }
                    $version = "${env:inject_version}"

                    echo $version

                    if (!($branchname -match "^master|release|develop"))
                    {
                    $versionlength = [math]::min( 20, $branchname.length )
            
                    $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                    $version = "$version-$branchname"
                    }
                    $version
                    "env.branchVersion='$version'" | Out-File ".\\variables.groovy" -Encoding ASCII'''

                    powershell '''Get-Content variables.groovy | Foreach-Object{
                    $var = $_.Split(\'=\')
                    New-Variable -Name $var[0] -Value $var[1]
                    }'''
                }

            }
        }
        })

        stage('Load Environment Variables 2', {
            
                steps {
                    dir("build/assemble/base"){
                script {
                    load "variables.groovy"                    
                    }
                }
            }
            
            }
        )


        stage('remove tests', {
            steps{
                dir("build") {
                script{
                    powershell '''
                    Remove-Item "assemble//base//tests" -recurse -force -verbose
                    Remove-Item "assemble//base//testdata" -recurse -force -verbose
                    Remove-Item "assemble//base//scripts" -recurse -force -verbose
                    '''
                     }
                }
            }
        })


        stage('Assemble configuration in zip file'){
            steps{
                dir("build") {
                script{
                    powershell '''
                    Compress-Archive -Path  "assemble\\base\\*"  "Base\\nice-aie-${env:branchVersion}.zip"   -Update
                        
                    '''
                }
                }
            }
        }  








    }
    post{
        success{
                script{
                    archiveArtifacts artifacts: '**/*.zip, **/artifactoryPackages.out,', allowEmptyArchive: true
                    powershell '''
                        jf rt u **/nice-aie*.zip nuget-snapshot-aws-local

                    '''

                }


            }
    }
}



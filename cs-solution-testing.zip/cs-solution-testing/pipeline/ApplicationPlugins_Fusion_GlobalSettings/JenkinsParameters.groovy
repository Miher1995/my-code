static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/fp/ApplicationPlugins.Fusion.GlobalSettings.git' }
static def repoName() { 'ApplicationPlugins.Fusion.GlobalSettings' }


return this

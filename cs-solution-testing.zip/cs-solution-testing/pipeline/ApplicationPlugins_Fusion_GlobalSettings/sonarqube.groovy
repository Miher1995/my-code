import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')

String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME



pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        choice(name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-VM-miher', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'build-agent-fmc-cs-windows'], description: 'Choice the slave')
    }
    agent {
        label "${params.SLAVE as String}"
    }
    


    stages {
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )

        stage('Repo Checkout on Slave', {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${env.gitlabBranch as String?:params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        })
        stage('Quality Gate') {
             environment {
                    scannerHome = 'C:/Users/Administrator/Downloads/sonar-scanner-msbuild-5.8.0.52797-net46/'
                    }     
                    steps {
                    withSonarQubeEnv('SonarQubeITPROD') {
                    echo "${scannerHome}"
                    bat '''
                    ls 
                    cd build/solutions/ApplicationPlugins.Fusion.GlobalSettings
                    C:/Users/Administrator/Downloads/sonar-scanner-msbuild-5.8.0.52797-net46/SonarScanner.MSBuild.exe begin /k:"FMC_ApplicationPlugins_Fusion_GlobalSettings" /d:sonar.host.url="https://sonar.nice.com/" 
                    "C:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\Community\\MSBuild\\Current\\Bin\\MSBuild.exe" /property:Configuration=Release -t:Rebuild
                    C:/Users/Administrator/Downloads/sonar-scanner-msbuild-5.8.0.52797-net46/SonarScanner.MSBuild.exe end 

                    '''

                        
                    }
                    }
                        }


        stage('Nuget Restore', {
                    steps {
                        script {
                            repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                            echo "${repoName}"
                            bat "nuget.exe restore build/solutions/${repoName}/${repoName}.sln" 

                        }
                    }
                })


        stage('MsBuild',{
            
            steps{
                script{
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    echo "${repoName}"
                    echo "Branch is: ${env.gitlabBranch}"
                    sh " '''C:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\Community\\MSBuild\\Current\\Bin\\MSBuild.exe'''   build/solutions/${repoName}/${repoName}.sln @build/solutions/properties.rsp "
                    }
                }
            })

        stage('Run Unit Tests',{
            steps{
                script{
                    powershell '''
                    $files = Get-ChildItem  -Recurse build\\tests\\**\\*in\\**\\*.UnitTests.dll | ForEach-Object{$_.FullName}
                    nunit-console.exe $files
                    '''
                }
            }
            
        })

        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/assemblies/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })
        stage('Workspace Cleanup', {
                steps{
                    cleanWs()
                }
            })



    }
    

post {
        always {
            script {
                sendEmailNotification(this, currentBuild.result as String, buildUserEmail)
            }
        }
    }
}


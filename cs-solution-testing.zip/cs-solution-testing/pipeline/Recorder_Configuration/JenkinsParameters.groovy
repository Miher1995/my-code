static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/Recorder.Configuration.git' }
static def repoName() { 'Recorder.Configuration' }


return this
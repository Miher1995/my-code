static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/fp/ApplicationPlugins.Fusion.CallSearch.git' }
static def repoName() { 'ApplicationPlugins.Fusion.CallSearch' }


return this

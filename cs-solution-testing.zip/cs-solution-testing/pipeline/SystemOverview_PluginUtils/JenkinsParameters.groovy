static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/SystemOverview.PluginUtils.git' }
static def repoName() { '/SystemOverview.PluginUtils' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/applicationframework/Nice.ApplicationFramework.git' }
static def repoName() { 'Nice.ApplicationFramework' }


return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/CoreLibraries.Audio.NMF.git' }
static def repoName() { 'CoreLibraries.Audio.NMF' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/apl/ApplicationPlugins.RoleConfiguration.git' }
static def repoName() { 'ApplicationPlugins.RoleConfiguration' }
static def folderName() { 'ApplicationPlugins_RoleConfiguration' }

return this

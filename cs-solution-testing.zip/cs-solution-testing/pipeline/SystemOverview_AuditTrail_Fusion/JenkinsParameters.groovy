static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/SystemOverview.AuditTrail.Fusion.git' }
static def repoName() { 'SystemOverview.AuditTrail.Fusion' }


return this
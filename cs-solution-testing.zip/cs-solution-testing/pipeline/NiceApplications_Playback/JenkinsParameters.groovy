static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/ex/NiceApplications.Playback.git' }
static def repoName() { 'NiceApplications.Playback' }


return this

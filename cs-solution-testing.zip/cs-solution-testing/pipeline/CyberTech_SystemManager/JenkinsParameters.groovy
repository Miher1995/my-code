static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/CyberTech.SystemManager.git' }
static def repoName() { 'CyberTech.SystemManager' }


return this
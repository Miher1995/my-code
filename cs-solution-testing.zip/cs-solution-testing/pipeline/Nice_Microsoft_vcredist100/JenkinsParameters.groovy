static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/Nice.Microsoft.vcredist100.git' }
static def repoName() { 'Nice.Microsoft.vcredist100' }
return this
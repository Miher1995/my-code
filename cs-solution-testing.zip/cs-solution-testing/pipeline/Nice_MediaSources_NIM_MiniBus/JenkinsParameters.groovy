static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csms/Nice.MediaSources.NIM.MiniBus.git' }
static def repoName() { 'Nice.MediaSources.NIM.MiniBus' }


return this

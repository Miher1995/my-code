static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ActiveIntelligenceEngine.ODBC.git' }
static def repoName() { 'Nice.ActiveIntelligenceEngine.ODBC' }


return this

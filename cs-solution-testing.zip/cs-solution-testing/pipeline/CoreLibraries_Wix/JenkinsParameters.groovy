static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/CoreLibraries.Wix.git' }
static def repoName() { 'CoreLibraries.Wix' }


return this

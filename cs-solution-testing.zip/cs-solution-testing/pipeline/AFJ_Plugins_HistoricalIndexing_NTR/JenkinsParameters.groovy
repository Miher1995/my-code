static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/apfjobs/applicationframework.jobs.plugins.historicalindexing.ntr.git' }
static def repoName() { 'AFJ.Plugins.HistoricalIndexing.NTR' }


return this

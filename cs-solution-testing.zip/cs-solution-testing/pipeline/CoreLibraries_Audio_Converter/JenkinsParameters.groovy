static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/corelibraries/CoreLibraries.Audio.Converter.git' }
static def repoName() { 'CoreLibraries.Audio.Converter' }


return this

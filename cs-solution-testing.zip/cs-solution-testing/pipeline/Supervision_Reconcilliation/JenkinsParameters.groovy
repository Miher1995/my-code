static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sup/Supervision.Reconcilliation.git' }
static def repoName() { 'Supervision.Reconcilliation' }


return this

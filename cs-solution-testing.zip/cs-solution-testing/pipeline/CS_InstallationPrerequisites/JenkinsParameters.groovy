static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/CS.InstallationPrerequisites.git' }
static def repoName() { 'CS.InstallationPrerequisites' }


return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/Compass.Reporting.git' }
static def repoName() { 'Compass.Reporting' }


return this

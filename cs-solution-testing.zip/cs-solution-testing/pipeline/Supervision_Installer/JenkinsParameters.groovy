static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sup/Supervision.Installer.git' }
static def repoName() { 'Supervision.Installer' }


return this

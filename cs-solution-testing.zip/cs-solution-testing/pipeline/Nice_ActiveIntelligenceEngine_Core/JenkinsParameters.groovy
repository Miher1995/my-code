static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ActiveIntelligenceEngine.Core.git' }
static def repoName() { 'Nice.ActiveIntelligenceEngine.Core' }


return this

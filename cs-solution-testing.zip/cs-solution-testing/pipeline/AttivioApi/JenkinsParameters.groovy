static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/AttivioApi.git' }
static def repoName() { 'AttivioApi' }


return this

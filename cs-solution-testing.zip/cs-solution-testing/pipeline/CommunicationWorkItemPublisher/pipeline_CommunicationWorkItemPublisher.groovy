import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl = 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/CommunicationWorkItemPublisher.git'

pipeline {

    agent {
        label 'build-agent-fmc-cs-windows'
    }


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
    }
    stages {
            stage('Preparations', {
                            steps {
                                script {
                                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                                    }
                                }
                            }
                        )

            stage('Git Checkout') {
                steps {
                    script {
                            git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                            )
                    }
                }
            }

    
        stage('Maven build') {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                    bat "ls -ltrh"
                    bat "mvn clean install -f maven\\CommunicationWorkItemPublisher\\pom.xml"


                    }
                }
            }
        }

        stage('Archive Artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/assemblies/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })

   
   
   
    }
}

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Monitoring.Client.git' }
static def repoName() { 'Monitoring.Client' }
return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/S3Downloader.git' }
static def repoName() { 'S3Downloader' }


return this

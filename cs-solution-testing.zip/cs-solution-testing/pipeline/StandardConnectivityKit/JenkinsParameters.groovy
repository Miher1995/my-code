static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sicc/StandardConnectivityKit.git' }
static def repoName() { 'StandardConnectivityKit' }

return this
import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM','Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '2.11.3', description: 'generic branch for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_SUBFOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
        string( name: 'FXT_VERSION', defaultValue: '4.5.0', description: 'FXT version of automation scripts artifacts')
        string( name: 'MSG_VERSION', defaultValue: '2.11.0', description: 'MSG version of automation scripts artifacts')
        string( name: 'BLOOMBERG_VERSION', defaultValue:'2.6.2', description: 'Bloomberg version of automation scripts artifacts')
        string( name: 'EMAILMAILBOX_VERSION', defaultValue: '2.2.0', description: 'EMAILMAILBOX version of automation scripts artifacts')
        string( name: 'TRC_VERSION', defaultValue: '2.7.0', description: 'TRC version of automation scripts artifacts')
        string( name: 'YIELDBROKER_VERSION', defaultValue: '2.6.0', description: 'YIELDBROKER version of automation scripts artifacts')
        string( name: 'RECONCILATION_VERSION', defaultValue: '1.3.0', description:'RECONCILATIONversion of automation scripts artifacts')
        string(name:'SKIP_PACKAGES',defaultValue:'empty',  description:'RECONCILATIONversion of automation scripts artifacts')
        string(name:'PACKAGE_OUTPUTFILENAME',defaultValue:'ARTIFACTORYPACKAGES.OUT',  description:'Package output file name  artifacts')
        string(name:'CUSTOMER',defaultValue:'test',  description:'customer value')
        string(name:'INJECTED_VERSION',defaultValue:'4.5.1',  description:'injected version')
        string(name:'ATTIVIO_BRANCHVERSION',defaultValue:'4.4',  description:'injected version')

    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{
         stage('Remove assemble dir', {
             steps{
				script{
					powershell '''
						if(Test-Path -Path "assemble/")
                            {
                                echo "Removing assemble folder"
                                Remove-Item -Recurse -Force "assemble/*"
                            }
					'''
                }
             }
         })
         stage('Resolve Base Config zip from artifactory'){
            steps{
                script{
                    sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                    powershell '''jf rt dl nuget-snapshot-aws-local/${env:BASE_SUBFOLDER}/nice-aie-${env:BASE_VERSION}.zip packages/ '''
                    bat 'ls -ltrh'
                }
            }
        }
stage('Unzip artifact from previous stage'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  packages/${env:BASE_SUBFOLDER}/nice-aie-${env:BASE_VERSION}.zip assemble/nice-aie -Force
					'''
				}
			}
		}
stage('Resolve FXT connector'){
            steps{
                script{
                    sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                    powershell ''' jf rt dl nuget-snapshot-aws-local/FXT/FXT-${env:FXT_VERSION}.zip  packages/ '''
                    bat 'ls -ltrh'
                }
            }
        }

      stage('unzip fxt connector'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  packages/FXT/FXT-${env:FXT_VERSION}.zip  assemble/fxt -Force
					'''
				}
			}
		}
      stage('Resolve Bloomberg from artifactory'){
            steps{
                script{
                    sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                    powershell ''' jf rt dl nuget-snapshot-aws-local/Bloomberg/Bloomberg-${env:BLOOMBERG_VERSION}.zip packages/ '''
                    bat 'ls -ltrh'
                }
            }
        }
        stage('Unzip Bloomberg'){
                    steps{
                        script{
                            powershell '''
                                Expand-Archive -Path  packages/Bloomberg/Bloomberg-${env:BLOOMBERG_VERSION}.zip assemble/bloomberg -Force
                            '''
                        }
                    }
                }

stage('Resolve MSG from artifactory'){
                    steps{
                        script{
                            sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                            powershell ''' jf rt dl nuget-snapshot-aws-local/MSG/MSG-${env:MSG_VERSION}.zip packages/ '''
                            bat 'ls -ltrh'
                        }
                    }
                }
            stage('Unzip MSG connector'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  packages/MSG/MSG-${env:MSG_VERSION}.zip assemble/msg -Force
                                '''
                            }
                        }
                    }
stage('Resolve emailMailbox configuration'){
                        steps{
                            script{
                                sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                                powershell '''jf rt dl nuget-snapshot-aws-local/emailMailboxConnector/emailMailboxConnector-${env:EMAILMAILBOX_VERSION}.zip packages/ '''
                                bat 'ls -ltrh'
                            }
                        }
                    }

            stage('Unzip emailMailboxFile connector'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  packages/emailMailboxConnector/emailMailboxConnector-${env:EMAILMAILBOX_VERSION}.zip assemble/emailMailboxConnector -Force
                                '''
                            }
                        }
                    }
stage('Resolve TRC from artifactory'){
                        steps{
                            script{
                                sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                                powershell '''jf rt dl nuget-snapshot-aws-local/TRC/TRC-${env:TRC_VERSION}.zip packages/ '''
                                bat 'ls -ltrh'
                            }
                        }
                    }
                    stage('Unzip TRC'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  packages/TRC/TRC-${env:TRC_VERSION}.zip assemble/trc -Force
                                '''
                            }
                        }
                    }

stage('Resolve YieldBroker from artifactory'){
                        steps{
                            script{
                                sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                                powershell ''' jf rt dl nuget-snapshot-aws-local/YieldBroker/YieldBroker-${env:YIELDBROKER_VERSION}.zip packages/ '''
                                bat 'ls -ltrh'
                            }
                        }
                    }

            stage('Unzip YieldBroker'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  packages/YieldBroker/YieldBroker-${env:YIELDBROKER_VERSION}.zip assemble/yieldbroker -Force
                                '''
                            }
                        }
                    }
                    stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )

                    stage('Git Checkout') {
                        steps {
                            script {
                                dir("assemble/cc_install_pack") {
                                    git(
                                        url: "${repositoryUrl}",
                                        credentialsId: "${git_user}",
                                        branch: "${params.BRANCH_NAME as String}"
                                    )
                                }
                            }
                        }
                    }
        
    stage('Reconciliation report install pack'){
                        steps{
                            script{
                                sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                                powershell ''' jf rt dl nuget-snapshot-aws-local/reconciliation-reporting/reconciliation-reporting-${env:RECONCILATION_VERSION}.zip packages/ '''
                                bat 'ls -ltrh'
                            }
                        }
                    }

            stage('Unzip reconciliation report'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  packages/reconciliation-reporting/reconciliation-reporting-${env:RECONCILATION_VERSION}.zip assemble/reconciliation -Force
                                '''
                            }
                        }
                    }
        stage('Remove reconsiliation if added to skipPackages'){
                        steps{
                            script{
                                powershell '''
                                $skipPackages = "${env:SKIP_PACKAGES}" -split ','

                                if($skipPackages -contains "reconciliation"){
                                echo "Removing reconciliation zip"
                                Remove-Item –path "packages/reconciliation-reporting/reconciliation-reporting-${env:RECONCILATION_VERSION}.zip"
                                echo "Removing content assemble/reconciliation folder"
                                Remove-Item -Recurse -Force "assemble/reconciliation/*"
                                }'''
                            }
                        }
                    }
            stage('Resolve base automation scripts from artifactory'){
                        steps{
                            script{
                                sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                                powershell ''' jf rt dl nuget-snapshot-aws-local/${env:BASE_SUBFOLDER}/nice-aie_automation-scripts-${env:BASE_VERSION}.zip '''
                                bat 'ls -ltrh'
                            }
                        }
                    }
            stage('Unzip base automation scripts'){
                        steps{
                            script{
                                powershell '''
                                    Expand-Archive -Path  ${env:BASE_SUBFOLDER}/nice-aie_automation-scripts-${env:BASE_VERSION}.zip assemble/baseautomationscripts -Force
                                '''
                            }
                        }
                    }

stage('Create output file with CreateArtifactoryPackageRestoreOutputFile script'){
			steps{
				script{
                    bat 'ls -ltrh'
                    powershell '''
                    "${env:BUILDSYSTEM_HOME}\\tools\\Atlassian\\CreateArtifactoryPackageRestoreOutputFile.ps1 -OutputFile ${env:PACKAGE_OUTPUTFILENAME} -PackagesLocation 'packages' -FileExtension '.zip'"
                    '''
					
                   

    }
}
        }

stage('Zip the FXT test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path  "assemble\\fxt\\testdata\\*"  fxt-testdata.zip  -Update 
                            '''
                }
            }
        }
stage('Zip the YBC test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\yieldbroker\\testdata\\*" ybc-testdata.zip -Update 
                            '''
                }
            }
        }

stage('Zip the Bloomberg test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\bloomberg\\testdata\\autotestdata\\*"  bloomberg-testdata.zip -Update 
                            '''
                }
            }
        }
stage('Zip the TRC test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\trc\\testdata\\autotestdata\\*" trc-testdata.zip -Update 
                            '''
                }
            }
        }

stage('Zip the MSG test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\msg\\testdata\\autotestdata\\*"  msg-testdata.zip -Update
                            '''
                }
            }
        }

stage('Zip the emailMailboxConnector test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\emailMailboxConnector\\testdata\\autotestdata\\*" emailMailbox-testdata.zip -Update
                            '''
                }
            }
        }

stage('Zip rest-service test data'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\baseautomationscripts\\testdata\\*" csv-testdata.zip -Update
                            '''
                }
            }
        }
 stage('Assemble configuration'){
                        steps{
                            script{
                                powershell '''


                                $TARGETDIR="assemble/target"
                                $TARGETDIR_NICE_AIE="assemble/target/nice-aie"
                                if( -Not (Test-Path -Path $TARGETDIR ) )
                                {
                                    New-Item -ItemType directory -Path $TARGETDIR
                                }

                                $skipPackages = "${env:SKIP_PACKAGES}" -split ','

                                Remove-Item -Recurse -Force $TARGETDIR/*
                                Copy-Item "assemble/nice-aie/*" -Destination $TARGETDIR -force -recurse
                                Copy-Item "assemble/bloomberg/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/fxt/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/msg/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/emailMailboxConnector/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/trc/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/yieldbroker/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                Copy-Item "assemble/cc_install_pack/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse

                                if($skipPackages -notcontains "reconciliation"){
                                    Copy-Item "assemble/reconciliation/nice-aie/*" -Destination $TARGETDIR_NICE_AIE -force -recurse
                                }

                                "version=${bamboo.inject.version}" | Out-File "$TARGETDIR/${bamboo.Customer}.properties" -Encoding ASCII
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "YeildBroker.version=${env:YIELDBROKER_VERSION}"
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "TRC.version=${env:TRC_VERSION}"
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "MsgFileConnector.version=${env:MSG_VERSION}"
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "Bloomberg.version=${env:BLOOMBERG_VERSION}"
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "FXT.version=${env:FXT_VERSION}"
                                Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "Base.version=${env:BASE_VERSION}"

                                if($skipPackages -notcontains "reconciliation"){
                                    Add-Content "$TARGETDIR/${env:CUSTOMER}.properties" "ReconciliationReport.version=${env:RECONCILATION_VERSION}"
                                }

                                echo List target 
                                Get-ChildItem -Force "$TARGETDIR"
                                echo --------------------------------------
                                echo List target/nice-aie 
                                Get-ChildItem -Force "$TARGETDIR_NICE_AIE"
                                echo --------------------------------------

                                exit $LASTEXITCODE

                                '''
                                }
                        }
                    }

stage('Execute emailMailbox, bloomberg and trc bat scripts'){
                        steps{
                            script{
                                
                                powershell '''
                                ls
                                cd assemble/target/nice-aie/
                                echo "Executing bloombergInstaller.bat"
                                Start-Process -Wait -FilePath "bloombergInstaller.bat"
                                echo "Executing trcInstaller.bat"
                                Start-Process -Wait -FilePath "trcInstaller.bat"
                                echo "Executing emailMailboxInstaller.bat"
                                Start-Process -Wait -FilePath "emailMailboxInstaller.bat"
                                exit $LASTEXITCODE
                                '''
                            }
                            }
                        }
stage('Clean up target folder from unneccesary files'){
                        steps{
                            script{
                                powershell '''
                                $TARGETDIR="assemble/target"
                                $TARGETDIR_NICE_AIE="assemble/target/nice-aie"

                                echo "Removing bloombergInstaller"
                                Remove-Item "$TARGETDIR_NICE_AIE/bloombergInstaller.bat"
                                echo "Removing trcInstaller"
                                Remove-Item "$TARGETDIR_NICE_AIE/trcInstaller.bat"
                                echo "Removing emailMAilboxInstaller"
                                Remove-Item "$TARGETDIR_NICE_AIE/emailMailboxInstaller.bat"

                                if(Test-Path -Path "$TARGETDIR/.git")
                                {
                                    echo "Removing git folder"
                                    Remove-Item -Recurse -Force $TARGETDIR/.git
                                }
                                if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes")
                                {
                                    echo "Removing ReleaseNotes file"
                                    Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes"
                                }
                                if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes.txt")
                                {
                                    echo "Removing ReleaseNotes.txt file"
                                    Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes.txt"
                                }
                                if(Test-Path -Path "$TARGETDIR_NICE_AIE/xsl")
                                {
                                    echo "Removing xsl extra folder"
                                    Remove-Item -Recurse -Force "$TARGETDIR_NICE_AIE/xsl"
                                }
                                if(Test-Path -Path "$TARGETDIR_NICE_AIE/testdata")
                                {
                                    echo "Removing testdata extra folder"
                                    Remove-Item -Recurse -Force "$TARGETDIR_NICE_AIE/testdata"
                                }

                                exit $LASTEXITCODE
                                '''
                            }
                                                          
                        }
}
    
stage('Create Customer folder'){
                        steps{
                            script{
                                powershell '''
                                if( -Not (Test-Path -Path ${env:CUSTOMER} ) )
                                {
                                    New-Item -ItemType directory -Path ${env:CUSTOMER}
                                }
                                '''
                            }
                        }  
}
stage('branch version'){
                  steps{
                       script{

                        powershell '''
                            $branchname = "${env:BRANCH_NAME}"
                            $version = "${env:version}"

                            if (!($branchname -match "^master|release|develop"))
                            {
                                $versionlength = [math]::min( 20, $branchname.length )
                                
                                $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                                $version = "$version-$branchname"
                            }

                            "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII

                    '''
                    }
                }
            }

stage('Assemble configuration in zip file'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\target\\*" ${env:CUSTOMER}/${env:CUSTOMER}-${env:INJECTED_VERSION}${env:ATTIVIO_BRANCHVERSION}.zip -Update
                            '''
                }
            }
        }

stage('Assemble test scripts'){
                    steps{
                        script{
                            powershell '''
                            $TARGETAUTODIR="assemble/auto_scripts"
if( -Not (Test-Path -Path $TARGETAUTODIR ) )
{
    New-Item -ItemType directory -Path $TARGETAUTODIR
}
Copy-Item "assemble/baseautomationscripts/*" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/yieldbroker/tests" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/fxt/tests" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/trc/tests" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/bloomberg/tests" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/msg/tests" -Destination $TARGETAUTODIR -force -recurse
Copy-Item "assemble/emailMailboxConnector/tests" -Destination $TARGETAUTODIR -force -recurse

Write-Output "List $TARGETAUTODIR" 
Get-ChildItem -Force "$TARGETAUTODIR"
Write-Output "--------------------------------------"    


                   
                    '''
                }
            }
        }

stage('Zip the test scripts'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "assemble\\auto_scripts\\*" AutomationScripts-${env:INJECT_VERSION}.zip -Update
                            '''
                }
            }
        }
stage('Artifactory Generic Deploy'){
                    steps{
                        script{
                            powershell '''
                                ls
                                cd test
                                 
                                jf rt u --flat=true  "*.zip/"  nuget-snapshot-aws-local/
                            '''
                }
            }
        }



    }
     post{
        always{
                script{
                    archiveArtifacts artifacts: '**/*.zip, **/artifactoryPackages.out,', allowEmptyArchive: true
                }


            }
    }

}
        
        
        
        
        
        
    

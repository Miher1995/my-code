static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CoreLibraries.Alarming.git' }
static def repoName() { 'CoreLibraries.Alarming' }


return this
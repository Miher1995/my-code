static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.QueryLevelReporting.git' }
static def repoName() { 'Nice.QueryLevelReporting' }
return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/ComponentSetup.Common.git' }
static def repoName() { 'ComponentSetup.Common' }


return this
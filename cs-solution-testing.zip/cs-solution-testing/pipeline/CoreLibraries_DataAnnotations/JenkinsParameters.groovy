static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/CoreLibraries.DataAnnotations.git' }
static def repoName() { 'CoreLibraries.DataAnnotations' }


return this

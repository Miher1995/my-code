static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/compass-provisioning-api/Compass.Api.Common.git' }
static def repoName() { 'Compass.Api.Common' }


return this
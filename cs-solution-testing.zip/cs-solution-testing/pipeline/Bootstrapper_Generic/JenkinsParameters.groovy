static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/Bootstrapper.Generic.git' }
static def repoName() { 'Bootstrapper.Generic' }


return this

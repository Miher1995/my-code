static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/Cybertech.Redundancy.git' }
static def repoName() { 'Cybertech.Redundancy' }


return this

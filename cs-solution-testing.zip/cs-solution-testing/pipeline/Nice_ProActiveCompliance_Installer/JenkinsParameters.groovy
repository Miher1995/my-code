static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ProactiveCompliance.Installer.git' }
static def repoName() { 'Nice.ProactiveCompliance.Installer' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.AppPlugins.IndexingConfiguration.git' }
static def repoName() { 'Nice.AppPlugins.IndexingConfiguration' }


return this

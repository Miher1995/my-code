static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/CS.InteractionAPI.git' }
static def repoName() { 'CS.InteractionAPI' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/Nice.Dart.PowerSNMP.git' }
static def repoName() { 'Nice.Dart.PowerSNMP' }


return this
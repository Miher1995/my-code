static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/apl/ApplicationPlugins.Monitoring.git' }
static def repoName() { 'ApplicationPlugins.Monitoring' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/auc/UIControls.ManualInteractionsImport.git' }
static def repoName() { 'UIControls.ManualInteractionsImport' }


return this
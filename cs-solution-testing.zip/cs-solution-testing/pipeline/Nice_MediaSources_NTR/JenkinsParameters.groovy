static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.MediaSources.NTR.git' }
static def repoName() { 'Nice.MediaSources.NTR' }


return this

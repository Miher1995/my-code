import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: [ 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'version', defaultValue: '4.4.1', description: 'generic versionfor build')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{


            stage('Preparations', {
                steps {
                    script {
                        repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                        }
                    }
                }
            )

            stage('Git Checkout') {
                steps {
                    script {
                            git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                            )
                    }
                }
            }

            stage('Build'){
                environment {
                    BUILDSYSTEM_HOME="C:\\build-farm\\"
                }
                  steps{
                       script{
                        sh "ls "
                        echo "List of files"
                        powershell '''
						cd solutions/
                        nant   nightly build  -D:CCNetLabel=${env:version}.${env:BUILD_NUMBER} -D:Bamboo= -D:Branch=${env:BRANCH_NAME}

                    '''
                    
                  }
            }
            }
        stage('JUNIT Parser configuration'){
                      steps{
                                script{
                                    bat "mvn clean install -f maven\\export-scenario-interactions\\target\\surefire-reports\\*.xml"

                                    String setting_file = "${WORKSPACE}/new"
                                      }
                           }
        }
                    
                    }
            }

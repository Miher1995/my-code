static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Scenario.Interaction.Details.Importer.git' }
static def repoName() { 'Scenario.Interaction.Details.Importer' }

return this

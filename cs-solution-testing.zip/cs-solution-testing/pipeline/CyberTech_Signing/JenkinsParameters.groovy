static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/CyberTech.Signing.git' }
static def repoName() { 'Signing' }


return this
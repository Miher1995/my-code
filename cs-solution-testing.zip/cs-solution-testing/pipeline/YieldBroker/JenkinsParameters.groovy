static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/YieldBroker.git' }
static def repoName() { 'YieldBroker' }

return this

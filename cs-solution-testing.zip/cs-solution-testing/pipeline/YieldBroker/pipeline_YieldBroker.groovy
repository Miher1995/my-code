import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: [ 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-VM-miher','Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'develop_test', description: 'generic branch for build')
        string( name: 'version', defaultValue: '2.5.0', description: 'generic branch for build')

        string( name: 'exchange_repo', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'exchange_version', defaultValue: '4.4.0', description: 'base version of automation scripts artifacts')
        string( name: 'include_exchange_jar', defaultValue: '2.7.0', description: 'base version of automation scripts artifacts')

        string( name: 'base_repo', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'base_folder', defaultValue: 'Base', description: 'base folder of automation scripts artifacts')
        string( name: 'base_version', defaultValue: '4.6.1', description: 'base folder of automation scripts artifacts')
        


    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{

        stage('Create branched version', {
            steps{
                script{
                    powershell '''
						$branchname = "${env:BRANCH_NAME_Version}"
						$version = "${env:version}"
						if (!($branchname -match "^master|release|develop"))
						{
							$versionlength = [math]::min( 20, $branchname.length )
							
							$branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
							$version = "$version-$branchname"
						}

						$version
						"branchVersion='$version'" | Out-File ".\\variables.groovy" -Encoding ASCII					
					'''
                }
            }
        })

        stage('Load Environment Variables', {
            steps {
                script {
                    load "variables.groovy"                    
                    }
                }
            }
        )

        stage('Maven Dependency Resolving and Packing', {
            steps{
                script{
                    powershell '''
						if(Test-Path -Path "pom.xml")
						{
						    mvn	clean install -D package.version=${env:branchVersion} -D version.number=${env:version} -D packageVersion.number=${env: branchVersion} -U -D skipTests
						}
					'''
                }
            }
        })

        stage('clean up local maven repo', {
            steps{
                script{
                    powershell '''
						if(Test-Path -Path "$env:USERPROFILE\\.m2")
						{
							echo "Removing m2 folder"
							Remove-Item -Recurse -Force $env:USERPROFILE\\.m2
						}					
					'''
                }
            }
        })


        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )


        stage('Git Checkout') {
            steps {
                script {
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                }
            }
        }

        stage('Project Dependencies'){
            environment {
                BUILDSYSTEM_HOME="C:/build-farm/"
            }

            steps{
                script{
                    powershell '''
                            Write-Output "Creating dependency list"
                            $currentDir = (Resolve-Path .\\).Path
                            $modules = @{}

                            if (Test-Path -Path "$currentDir\\pom.xml")
                            {
                                [xml]$pom = Get-Content "$currentDir\\pom.xml"
                                foreach($module in $pom.project.modules.module)
                                {
                                    $modules.Set_Item($module,$null)
                                }
                            }
                            else
                            {
                                    Write-Host "Error: No pom found."
                                    exit -1
                            }

                            $mvnExe = "mvn"
                            $params = @('dependency:tree', '-DappendOutput', '-DoutputAbsoluteArtifactFilename', "-DoutputFile=$currentDir\\restore.mvn")

                            Write-Output "Executing maven ($mvnExe $params)"
                            & $mvnExe $params

                            if ($LastExitCode -ne 0)
                            {
                                Write-Output "ERROR: Error while executing maven." 
                                Exit $LastExitCode
                            }

                            try
                            {    
                                Get-Content "$currentDir\\restore.mvn" |` 
                                    Select-String '^\\s{3}([^:]+):([^:]+):jar:(?:([^:]+):)?([^:]+):(?:provided|compile|test|runtime):(.+)' -AllMatches |`
                                    Foreach {
                                        
                                    $matchGroups = $_.Matches.Groups
                                    $artifactId = $matchGroups[2].Value 
                                
                                    if (-not ($modules.ContainsKey($artifactId))){
                                        $groupId = $matchGroups[1].Value    
                                        $classifier = $matchGroups[3].Value
                                        $version = $matchGroups[4].Value
                                        $absolutePath = $matchGroups[5].Value        
                                        $shaFullPath = "$absolutePath.sha1"

                                        $sha1 = if (-not( Test-Path -Path $shaFullPath)){ $(Get-FileHash $absolutePath -Algorithm SHA1).Hash } `
                                                    else { (Get-Content $shaFullPath -First 1)}
                                        $sha1 = $sha1.Substring(0,40).ToLower() 

                                        $fileName = if ([string]::IsNullOrWhiteSpace($classifier)) {"$artifactId-$version.jar"} `
                                                        else {"$artifactId-$version-$classifier.jar"}

                                        Add-Content "$currentDir\\restore.out" "$($groupId -replace "\\.","/")/$artifactId/$version/${filename}:$sha1"
                                    }
                                }
                                Write-Output "restore.out is created"
                            }
                            catch
                            {
                                Write-Output $_.Exception.Message
                                Exit -1
                            }

                    '''
                }
            }
        }

            
        stage('Unzip artifact from previous stage'){
                    steps{
                        script{
                            powershell '''
                                Expand-Archive -Path  target\\YieldBroker-${env:branchVersion}.zip  assemble/ybc -Force
                            '''
                        }
                    }
                }

        stage('Zip the YBC test data'){
            steps{
                script{
                    powershell '''
                        Compress-Archive -Path  "assemble\\ybc\\testdata\\*"  ybc-testdata.zip -Update
                    '''
                }
            }
        }
        


        stage('Resolve base config from artifactory'){
                    steps{
                        script{
                            sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                            sh "jf rt dl ${params.BASE_REPO as String}/Base/nice-aie-${params.BASE_VERSION as String}.zip"
                            bat 'ls -ltrh'
                        }
                    }
                }

        stage('Unzip base config'){
            steps{
                script{
                    powershell '''
                        Expand-Archive -Path  Base/nice-aie-${env:BASE_VERSION}.zip  assemble/nice-aie/base  -Force
                    '''
                }
            }
        }


		stage('Resolve base automation scripts from artifactory'){
			steps{
				script{
					sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
					sh "jf rt dl ${params.BASE_REPO as String}/Base/nice-aie_automation-scripts-${params.BASE_VERSION as String}.zip"
					bat 'ls -ltrh'
				}
			}
		}
		stage('Unzip base automation scripts'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  Base/nice-aie_automation-scripts-${env:BASE_VERSION}.zip  assemble/nice-aie/auto  -Force
					'''
				}
			}
		}

		stage('Assemble configuration'){
			steps{
				script{
					powershell '''

                        $TARGETDIR="assemble/target"
                        $TARGETDIR_NICE_AIE="assemble/target/nice-aie"
                        if( -Not (Test-Path -Path $TARGETDIR ) )
                        {
                            New-Item -ItemType directory -Path $TARGETDIR
                        }
                        echo --------------------------------------
                        echo --------------------------------------
                        echo --------------------------------------
                        Get-ChildItem -Force "assemble/ybc/" -recurse
                        echo --------------------------------------
                        echo --------------------------------------
                        echo --------------------------------------
                        Remove-Item -Recurse -Force $TARGETDIR/*
                        Copy-Item "assemble/nice-aie/base/*" -Destination $TARGETDIR -force -recurse
                        Copy-Item "assemble/nice-aie/auto/*" -Destination $TARGETDIR -force -recurse
                        Copy-Item "assemble/ybc/*" -Destination $TARGETDIR -force -recurse

                        echo List target 
                        Get-ChildItem -Force "$TARGETDIR"
                        echo --------------------------------------
                        echo List target/nice-aie 
                        Get-ChildItem -Force "$TARGETDIR_NICE_AIE"
                        echo --------------------------------------

                        exit $LASTEXITCODE


						'''
				}
			}
		}

		stage('Clean up target folder from unneccesary files'){
			steps{
				script{
					powershell '''

                        $TARGETDIR="assemble/target"
                        $TARGETDIR_NICE_AIE="assemble/target/nice-aie"


                        if(Test-Path -Path "$TARGETDIR/.git")
                        {
                            echo "Removing git folder"
                            Remove-Item -Recurse -Force $TARGETDIR/.git
                        }
                        if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes")
                        {
                            echo "Removing ReleaseNotes file"
                            Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes"
                        }
                        if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes.txt")
                        {
                            echo "Removing ReleaseNotes.txt file"
                            Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes.txt"
                        }

                        if(Test-Path -Path "$TARGETDIR_NICE_AIE/testdata")
                        {
                            echo "Removing testdata extra folder"
                            Remove-Item -Recurse -Force "$TARGETDIR_NICE_AIE/testdata"
                        }

                        exit $LASTEXITCODE

						'''
				}
			}
		}

		stage('Post-Compile Clean up target folder from unneccesary files'){
			steps{
				script{
					powershell ''' 
						if( -Not (Test-Path -Path "YBC" ) )
						{
							New-Item -ItemType directory -Path "YBC"
						}
					'''
					}
				}
			}

		stage('Assemble configuration in zip file'){
			steps{
				script{
					powershell '''
						Compress-Archive -Path  "assemble\\target\\*"  YBC/YBC-WITH-BASE.zip -Update
					'''
				}
			}
		}		
    }
    post{
        success{
                script{
                    archiveArtifacts artifacts: '**/*.zip', allowEmptyArchive: true
                    powershell '''
                        jf rt u **/*.zip nuget-snapshot-aws-local
                    '''

                }
            }
    }


}

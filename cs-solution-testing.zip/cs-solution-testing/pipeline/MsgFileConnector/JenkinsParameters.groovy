static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/MsgFileConnector.git' }
static def repoName() { 'MsgFileConnector' }

return this

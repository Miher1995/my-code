static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/connectivity/ParrotApi.git' }
static def repoName() { 'ParrotApi' }


return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/NexidiaSearchGrid.ConfigurationPlugin.git' }
static def repoName() { 'NexidiaSearchGrid.ConfigurationPlugin' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/ex/Nice.SmartIndex.IndexRetentionManager.git' }
static def repoName() { 'IndexRetentionManager' }

return this

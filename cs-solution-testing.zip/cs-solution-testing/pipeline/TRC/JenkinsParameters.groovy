static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/ThomsonReuters.git' }
static def repoName() { 'ThomsonReuters' }

return this

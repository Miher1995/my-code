static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csp/ApplicationPlugins.ObserveRunnerConfiguration.git' }
static def repoName() { 'ApplicationPlugins.ObserveRunnerConfiguration' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/CyberTech.AlarmingV2.git' }
static def repoName() { 'CyberTech.AlarmingV2' }


return this
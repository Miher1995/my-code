static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/auc/UIControls.Dashboard.git' }
static def repoName() { 'Dashboard' }


return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/ActiveIntelligenceEngine.Setup.git' }
static def repoName() { 'ActiveIntelligenceEngine.Setup' }


return this
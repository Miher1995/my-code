static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/applicationframework/Nice.ApplicationFramework.Client.git' }
static def repoName() { 'Nice.ApplicationFramework.Client' }


return this

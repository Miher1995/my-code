static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/Alvas.Audio.git' }
static def repoName() { 'Alvas.Audio' }


return this

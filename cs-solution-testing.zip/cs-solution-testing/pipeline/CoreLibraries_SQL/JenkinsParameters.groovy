static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/CoreLibraries.SQL.git' }
static def repoName() { 'CoreLibraries.SQL' }


return this

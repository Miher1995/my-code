static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/TranscriptionAgent.Interface.git' }
static def repoName() { 'TranscriptionAgent.Interface' }


return this
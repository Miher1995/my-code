static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/CoreLibraries.Logging.git' }
static def repoName() { 'CoreLibraries.Logging' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/ActiveIntelligenceEngine.Installer.Utils.git' }
static def repoName() { 'ActiveIntelligenceEngine.Installer.Utils' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ApplicationPlugins.ComplianceDashboard.git' }
static def repoName() { 'CyberTech.ComplianceDashboard' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csms/Nice.MediaSources.Files.git' }
static def repoName() { 'Nice.MediaSources.Files' }


return this

 import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '2.11.3', description: 'generic branch for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'buildNumber', defaultValue: '1', description: 'buildNumber')

    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{
        stage('Create branched version', {
            steps{
                script{
                    powershell '''
                    $branchname = "${env:BRANCH_NAME_Version}"

                    if (!($branchname -match "^master|release|develop"))
                    {
                        $versionlength = [math]::min( 20, $branchname.length )
                        
                        $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                        $version = "-$branchname"
                    }

                    "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII'''
                }
            }
        })
                        stage('Preparations', {
                            steps {
                                script {
                                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                                    }
                                }
                            }
                        )

                    stage('Git Checkout') {
                            steps {
                                script {
                                    dir("reconciliation-${env:BRANCH_NAME_Version}-${env:buildNumber}/source") {
                                        git(
                                            url: "${repositoryUrl}",
                                            credentialsId: "${git_user}",
                                            branch: "${params.BRANCH_NAME as String}"
                                    )
                                }
                            }
                        }
                    }
                }
            }


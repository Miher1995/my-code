static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/ReconciliationReporting.git' }
static def repoName() { 'ReconciliationReporting' }

return this

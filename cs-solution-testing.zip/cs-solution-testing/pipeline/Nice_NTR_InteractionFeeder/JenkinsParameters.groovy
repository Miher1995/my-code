static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.NTR.InteractionFeeder.git' }
static def repoName() { 'Nice.NTR.InteractionFeeder' }


return this

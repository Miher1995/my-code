static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/SystemOverview.Topology.Plugin.git' }
static def repoName() { 'SystemOverview.Topology' }


return this

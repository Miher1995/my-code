static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csp/ApplicationPlugins.Labels.git' }
static def repoName() { 'ApplicationPlugins.Labels' }


return this

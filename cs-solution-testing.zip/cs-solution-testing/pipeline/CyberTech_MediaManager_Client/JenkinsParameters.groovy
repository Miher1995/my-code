static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CyberTech.MediaManager.Client.git' }
static def repoName() { 'CyberTech.MediaManager.Client' }


return this
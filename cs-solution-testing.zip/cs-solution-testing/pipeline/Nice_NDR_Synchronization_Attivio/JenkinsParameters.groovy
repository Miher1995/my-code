static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/nice.ndr.synchronization.attivio.git' }
static def repoName() { 'nice.ndr.synchronization.attivio' }


return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/corelibraries/CoreLibraries.git' }
static def repoName() { 'CoreLibraries' }


return this

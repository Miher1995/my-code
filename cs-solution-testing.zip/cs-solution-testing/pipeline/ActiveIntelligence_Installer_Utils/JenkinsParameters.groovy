static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/ActiveIntelligence.Installer.Utils.git' }
static def repoName() { 'ActiveIntelligence.Installer.Utils' }


return this

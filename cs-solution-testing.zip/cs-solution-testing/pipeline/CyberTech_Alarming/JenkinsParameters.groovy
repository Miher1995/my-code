static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CyberTech.Alarming.git' }
static def repoName() { 'CyberTech.Alarming' }


return this

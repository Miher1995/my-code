static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/fp/ApplicationPlugins.Fusion.NtrClustersStatus.git' }
static def repoName() { 'AppPlugin.Fusion.NtrCS' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/Compass.Configuration.git' }
static def repoName() { 'Compass.Configuration' }
static def configuration() { '/property:Configuration=Release' }
static def platform() { '' }



return this

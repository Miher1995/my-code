static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csms/NiceTradingRecording.Configuration.Interface.git' }
static def repoName() { 'MediaSources.NTR.Configuration.Interface' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CyberTech.ContentManager.git' }
static def repoName() { 'CyberTech.ContentManager' }


return this
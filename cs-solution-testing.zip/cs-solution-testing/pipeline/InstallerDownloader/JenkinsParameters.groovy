static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs-test-tooling/InstallerDownloader.git' }
static def repoName() { 'InstallerDownloader' }


return this

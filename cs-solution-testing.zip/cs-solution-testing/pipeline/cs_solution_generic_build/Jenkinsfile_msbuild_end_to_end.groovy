import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')

String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME



pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        string(defaultValue: '1.0.0', description: 'generic branch for build', name: 'inject_version')
        choice(name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'build-agent-fmc-cs-windows'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        booleanParam(name: 'BLACKDUCK_SCAN', defaultValue: 'false', description: 'Whether to scan with BlackDuck')
        booleanParam(name: 'PERFORM_RELEASE', defaultValue: 'false', description: 'Perform Release')


    }

    agent {
        label "${params.SLAVE as String}"
    }
    


    stages {
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )

        stage('Repo Checkout on Slave', {
            steps {
                script {
                    dir("build") {
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${env.gitlabBranch as String?:params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        })

        stage('Inject Versions', {
            environment {
                BUILDSYSTEM_HOME="C:\\build-farm\\"
            }
            steps {
                script {
                    echo "Inejcting Versions"
                    sh '''
                    export curr_dir=$PWD
                    echo $curr_dir
                    python ${BUILDSYSTEM_HOME}/scripts/Python/Inject.py ${inject_version} $curr_dir'''
                }
            }
        })

        stage('Nuget Restore', {
            steps {
                script {
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    echo "${repoName}"
                    bat "nuget.exe restore build/solutions/${repoName}/${repoName}.sln" 

                }
            }
        })


        stage('MsBuild',{
            environment {
                BUILDSYSTEM_HOME="C:/build-farm"
            }
            steps{
                script{
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    echo "${repoName}"
                    echo "Branch is: ${env.gitlabBranch}"
                    sh " '''C:\\Program Files (x86)\\Microsoft Visual Studio\\2019\\Community\\MSBuild\\Current\\Bin\\MSBuild.exe'''   build/solutions/${repoName}/${repoName}.sln @build/solutions/properties.rsp "
                    }
                }
            })

        stage('Run Unit Tests',{
            steps{
                script{
                    powershell '''
                    $files = Get-ChildItem  -Recurse build\\tests\\**\\*in\\**\\*.UnitTests.dll | ForEach-Object{$_.FullName}
                    nunit-console.exe $files
                    '''
                }
            }            
        })



        stage('Veracode Scan') {
            environment {
                BUILDSYSTEM_HOME="C:/build-farm"
            }

            when {
                expression {
                    return params.VERACODE_SCAN == true
                }
            }
            steps {
                script {
                    dir("build") {
                        echo "${repoName}"
                        echo "Calling veracode scan"
                        appArtifactId = "${env.JOB_BASE_NAME}"
                        appVersion = "${inject_version}"
                        zipFile = "${appArtifactId}.zip"
                        sh '''
                        export curr_dir=$PWD
                        python ${BUILDSYSTEM_HOME}/scripts/Python/compress.py  $curr_dir ${JOB_BASE_NAME}
                        '''
                        powershell '''
                        Compress-Archive -Path temp\\* "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''

                        echo "Collected information from msbuild appArtifactId=${appArtifactId}, appVersion=${appVersion}"
                        appName = "ACT_FMC_CS_${appArtifactId}"
                        echo "Calling veracode scan with zipFile=${zipFile}, appName=${appName}"
                    }
                    dir("build") {
                        echo "Using zipFile=${zipFile}, appName=${appName}"
                        veraCodeScan(this, "${appName}", "${workspace}/build/${zipFile}", "java", false, "DevSandbox", true, "/home/ec2-user")
                    }
                }
            }
        }

        stage('Blackduck Scan') {
            when {
                expression {
                    return params.BLACKDUCK_SCAN == true
                }
            }
            steps {

                echo "Package Stage completed"

                echo "Starting Blackduck scan"
                script {
                    dir("build") {
                        echo "Calling Blackduck scan"
                        repo_packages = "./solutions/**/packages/*"
                        venvFolderName = "${env.JOB_BASE_NAME}"
                        zipFile = "${env.JOB_BASE_NAME}.zip"
                        
                        powershell '''
                        Compress-Archive -Path ./solutions/**/packages/*  "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''
                        echo "venv Zip folder created zipFile=${zipFile}"
                        appName = "ACT_FMC_CS_${env:JOB_BASE_NAME}"
                        echo "Calling Blackduck scan with zipFile=${zipFile}, appName=${appName}"
                        blackduckScan("${appName}", "${params.inject_version}", "${WORKSPACE}/build/${zipFile}")
                        echo "Blackduck Scan completed"
                    }
                }
            }
          }

        stage('Release COP Validator', {
            environment {
                BUILDSYSTEM_HOME="C:\\build-farm\\"
            }
            when {
                expression {
                    return params.PERFORM_RELEASE == true
                }
            }

            steps {
                script {
                    echo "Inejcting Versions"
                    sh '''
                    export curr_dir=$PWD
                    echo $curr_dir
                    python ${BUILDSYSTEM_HOME}/scripts/Python/PreRelease.py $curr_dir'''
                }
            }
        })



    }

    post {

            success{
                    script {
                        dir("build"){
                            echo "Archiving Artifacts"
                            sh '''
                            export BUILDSYSTEM_HOME=/c/build-farm
                            export curr_dir=$PWD
                            echo $curr_dir
                            python ${BUILDSYSTEM_HOME}/scripts/Python/archive.py $curr_dir
                            
                            jf rt u --flat=true  archive/  nuget-snapshot-aws-local                    
                            '''
                        }
                    }
            }


            always {
                script {
                    buildUserEmail = "${env.BUILD_USER_EMAIL}"
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/tests/**,  build/assemblies/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true

                    sendEmailNotification(this, currentBuild.result as String, buildUserEmail)
                    // cleanWs()
                }

            }



        }
}


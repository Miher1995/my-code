import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')

String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME



pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        string(defaultValue: '1.0.0', description: 'generic branch for build', name: 'inject_version')
        choice(name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'build-agent-fmc-cs-windows'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        booleanParam(name: 'BLACKDUCK_SCAN', defaultValue: 'false', description: 'Whether to scan with BlackDuck')
        booleanParam(name: 'PERFORM_RELEASE', defaultValue: 'false', description: 'Perform Release and push artifacts to JFrog artifactory')

    }

    agent {
        label "${params.SLAVE as String}"
    }
    


    stages {

        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )

        stage('Repo Checkout on Slave', {
            steps {
                script {
                    dir("build") {
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${env.gitlabBranch as String?:params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        })


        stage('Nuget Restore', {
            steps {
                script {
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    echo "${repoName}"
                    bat "nuget.exe restore build/solutions/${repoName}/${repoName}.sln" 

                }
            }
        })



        stage('Blackduck Scan') {
            when {
                expression {
                    return params.BLACKDUCK_SCAN == true
                }
            }
            steps {

                echo "Package Stage completed"

                echo "Starting Blackduck scan"
                script {
                    dir("build") {
                        echo "Calling Blackduck scan"
                        repo_packages = "./solutions/**/packages/*"
                        venvFolderName = "${env.JOB_BASE_NAME}"
                        zipFile = "${env.JOB_BASE_NAME}.zip"
                        
                        powershell '''
                        Compress-Archive -Path ./solutions/**/packages/*  "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''
                        echo "venv Zip folder created zipFile=${zipFile}"
                        appName = "ACT_FMC_CS_${env:JOB_BASE_NAME}"
                        echo "Calling Blackduck scan with zipFile=${zipFile}, appName=${appName}"
                        blackduckScan("${appName}", "${params.inject_version}", "${WORKSPACE}/build/${zipFile}")
                        echo "Blackduck Scan completed"
                    }
                }
            }
          }
    }


}


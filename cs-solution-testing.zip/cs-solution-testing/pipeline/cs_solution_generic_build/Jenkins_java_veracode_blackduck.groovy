import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName

pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        choice(name: 'SLAVE', choices: ['build-agent-fmc-cs-windows', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        booleanParam(name: 'BLACKDUCK_SCAN', defaultValue: 'false', description: 'Whether to scan with BlackDuck')
    }
    agent {
        label "${params.SLAVE as String}"
    }
    

    stages {
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )

        stage('Repo Checkout') {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        }

        stage('Maven build') {
            steps {
                script {
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                    bat "ls -ltrh"
                    
                    sh "mvn clean install -f maven/${env:repoName}/pom.xml  -X"


                    }
                }
            }
        }

        stage('Veracode Scan') {
            when {
                expression {
                    return params.VERACODE_SCAN == true
                }
            }
            steps {
                script {
                    dir("build") {
                        echo "${repoName}"
                        echo "Calling veracode scan"
                        appArtifactId = "${env.JOB_BASE_NAME}"
                        appVersion = "4.6.1"
                        echo "Collected information from pom.xml appArtifactId=${appArtifactId}, appVersion=${appVersion}"
                        zipFile = "${appArtifactId}.zip"
                        appName = "ACT_FMC_CS_${appArtifactId}"
                        powershell '''
                        Compress-Archive -Path ./maven/**/target "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''
                        echo "Calling veracode scan with zipFile=${zipFile}, appName=${appName}"
                    }
                    dir("build") {
                        echo "Using zipFile=${zipFile}, appName=${appName}"
                        veraCodeScan(this, "${appName}", "C:/workspace/FMC/CS/${appArtifactId}/build/${zipFile}", "java", false, "DevSandbox", true, "/home/ec2-user")
                    }
                }
            }
        }
        stage('Blackduck Scan') {
            when {
                expression {
                    return params.BLACKDUCK_SCAN == true
                }
            }
            steps {

                echo "Package Stage completed"

                echo "Starting Blackduck scan"
                script {
                    dir("build") {
                        echo "Calling Blackduck scan"
                        echo "${repoName}"
                        appArtifactId = "${env.JOB_BASE_NAME}"
                        appVersion = "4.6.1"
                        venvFolderName = "${repoName}"
                        zipFile = "${venvFolderName}.zip"
                        //sh "zip -r ${zipFile} ${venvFolderName}/"
                        powershell '''$venvFolderName = "${venvFolderName}"
                        $zipFile = "${venvFolderName}.zip"
                        Compress-Archive -Path ./maven/**/target -DestinationPath $zipFile -Force
                        ls
                        '''
                        echo "venv Zip folder created zipFile=${zipFile}"
                        echo "Collected information from pom.xml appArtifactId=${appArtifactId}, appVersion=${appVersion}"
                        //zipFile = "${appArtifactId}-${appVersion}.zip"
                        appName = "FMC_CS_${appArtifactId}"
                        echo "Calling Blackduck scan with zipFile=${zipFile}, appName=${appName}"
                        blackduckScan("ACT_${appName}", "${appVersion}", "C:/workspace/FMC/CS/${appArtifactId}/build/${zipFile}")
                        echo "Blackduck Scan completed"
                    }
                }
            }
        }
        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/assemblies/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })
        stage('Workspace Cleanup', {
                steps{
                    cleanWs()
                }
            })
    }
            
        post {
                always {
                    script {
                        sendEmailNotification(this, currentBuild.result as String, buildUserEmail)
                    }
                }
            }
}




import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME

pipeline {

    agent {
        label 'build-agent-fmc-cs-windows'
    }


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
    }

    stages {
        stage('Preparations', {
            steps {
                script {
            
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )
        stage('MSBuild', {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        })
        stage('Build',{
            environment {
                BUILDSYSTEM_HOME="C:/work/build-farm"
            }
            steps{
                script{
                    echo "${repositoryUrl}"
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    echo "${repoName}"
                    bat "msbuild.exe build/solutions/${repoName}/${repoName}.sln @build/properties.rsp"
                    }
                }
            })
        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: 'build/deployments/SystemOverview.Compass.Channels.NuGet/Bin/*'
                    }
                }
            })
        } 
    }

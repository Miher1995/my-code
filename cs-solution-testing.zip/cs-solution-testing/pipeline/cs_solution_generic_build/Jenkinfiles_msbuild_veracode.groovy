import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME



pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        string( name: 'blackduck_version', defaultValue: '1.0', description: 'generic branch for build')
        choice(name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'build-agent-fmc-cs-windows'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        booleanParam(name: 'BLACKDUCK_SCAN', defaultValue: 'false', description: 'Whether to scan with BlackDuck')
    }
    agent {
        label "${params.SLAVE as String}"


    }
    


    stages {


        stage('Veracode Scan') {
            when {
                expression {
                    return params.VERACODE_SCAN == true
                }
            }
            steps {
                script {
                    dir("build") {
                        echo "${repoName}"
                        echo "Calling veracode scan"
                        appArtifactId = "${env.JOB_BASE_NAME}"
                        appVersion = "4.6.1"
                        zipFile = "${appArtifactId}.zip"
                        powershell '''
                        Compress-Archive -Path ./assemblies/**/**/**/*.pdb, ./assemblies/**/**/**/*.dll "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''
                        echo "Collected information from msbuild appArtifactId=${appArtifactId}, appVersion=${appVersion}"
                        appName = "ACT_FMC_CS_${appArtifactId}"
                        echo "Calling veracode scan with zipFile=${zipFile}, appName=${appName}"
                    }
                    dir("build") {
                        echo "Using zipFile=${zipFile}, appName=${appName}"
                        veraCodeScan(this, "${appName}", "${workspace}/build/${zipFile}", "java", false, "DevSandbox", true, "/home/ec2-user")
                    }
                }
            }
        }

        stage('Blackduck Scan') {
            when {
                expression {
                    return params.BLACKDUCK_SCAN == true
                }
            }
            steps {

                echo "Package Stage completed"

                echo "Starting Blackduck scan"
                script {
                    dir("build") {
                        echo "Calling Blackduck scan"
                        repo_packages = "./solutions/**/packages/*"
                        venvFolderName = "${env.JOB_BASE_NAME}"
                        zipFile = "${env.JOB_BASE_NAME}.zip"
                        
                        powershell '''
                        Compress-Archive -Path ./solutions/**/packages/*  "${env:JOB_BASE_NAME}.zip" -Force
                        ls
                        '''
                        echo "venv Zip folder created zipFile=${zipFile}"
                        appName = "ACT_FMC_CS_${env:JOB_BASE_NAME}"
                        echo "Calling Blackduck scan with zipFile=${zipFile}, appName=${appName}"
                        blackduckScan("${appName}", "${params.blackduck_version}", "${WORKSPACE}/build/${zipFile}")
                        echo "Blackduck Scan completed"
                    }
                }
            }
          }

        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe', excludes: 'build/solutions/**'
                    cleanWs()
                }
            }
        })

  //      stage('push artifacts to JFrog', {
  //          steps{
  //             script{
  //                  sh 'jf rt u build/deployments/**/*in/**/*.nupkg  nuget-snapshot-aws-local/'
  //              }
  //         }
  //      })
    }
}


import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')

String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME



pipeline {


    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        string(defaultValue: '1.0.0', description: 'generic branch for build', name: 'inject_version')
        choice(name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'build-agent-fmc-cs-windows'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        booleanParam(name: 'BLACKDUCK_SCAN', defaultValue: 'false', description: 'Whether to scan with BlackDuck')
        booleanParam(name: 'PERFORM_RELEASE', defaultValue: 'false', description: 'Perform Release')


    }

    agent {
        label "${params.SLAVE as String}"
    }
    


    stages {
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )



        stage('Release COP Validator', {
            environment {
                BUILDSYSTEM_HOME="C:\\build-farm\\"
            }
            when {
                expression {
                    return params.PERFORM_RELEASE == true
                }
            }

            steps {
                script {
                    echo "Inejcting Versions"
                    sh '''
                    export curr_dir=$PWD
                    echo $curr_dir
                    python ${BUILDSYSTEM_HOME}/scripts/Python/PreRelease.py $curr_dir'''
                }
            }
        })



    }

}


import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '2.11.3', description: 'generic branch for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{
        stage('Create branched version', {
            steps{
                script{
                    powershell '''$branchname = "${env:BRANCH_NAME_Version}"
                    $version = "${env:Version}"

                    echo $version

                    if (!($branchname -match "^master|release|develop"))
                    {
                    $versionlength = [math]::min( 20, $branchname.length )
            
                    $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                    $version = "$version-$branchname"
                    }
                    $version
                    "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII'''

                    powershell '''Get-Content bamboo.variables | Foreach-Object{
                    $var = $_.Split(\'=\')
                    New-Variable -Name $var[0] -Value $var[1]
                    }'''
                }
            }
        })
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )


        stage('Git Checkout') {
            steps {
                script {
                    dir("Bloomberg/source") {
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                    }
                }
            }
        }
        stage('Clean up configuration'){
            steps{
                script{
                    powershell '''Get-ChildItem Bloomberg/source
                    echo ------------------
                    if(Test-Path -Path "Bloomberg/source/.git")
                    {
                        Write-Host "Removing git folder"
                        Remove-Item -Recurse -Force Bloomberg/source/.git -Verbose
                    }
                    if(Test-Path -Path "Bloomberg/source/docs")
                    {
                        Write-Host "Removing doc folder"
                        Remove-Item -Recurse -Force Bloomberg/source/docs -Verbose
                    }
                    if(Test-Path -Path "Bloomberg/source/ReleaseNotes")
                    {
                        Write-Host "Removing ReleaseNotes file"
                        Remove-Item -Force Bloomberg/source/ReleaseNotes -Verbose
                    }'''
                }
            }
        }
        stage('Resolve nice-bloomberg jar from artifactory'){
            steps{
                script{
                    sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                    powershell '''jf rt dl nuget-snapshot-aws-local/Attivio_4x_jars/${env:Version}/nice-bloomberg-${env:Version}-jar-with-dependencies.jar'''
                    bat 'ls -ltrh'
                }
            }
        }

        stage('Move nice-bloomberg jar to nice-aie folder'){
            steps{
                script{
                    powershell '''
                    $jar="Attivio_4x_jars/${env:Version}/nice-bloomberg-${env:Version}-jar-with-dependencies.jar"
                    $NICE_AIE_LIB_OVERRIDE="Bloomberg/source/nice-aie/lib-override"

                    Move-Item $jar -Destination $NICE_AIE_LIB_OVERRIDE -Force -Verbose

                    '''
                }
            }
        }

        stage('Zip Bloomberg configuration'){
            steps{
                script{
                    powershell '''
                        Compress-Archive -LiteralPath  Bloomberg/source  Bloomberg/Bloomberg-${env:BRANCH_NAME_Version}.zip
                    '''
                }
            }
        }


		stage('Unzip artifact from previous stage'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  Bloomberg/Bloomberg-${env:BRANCH_NAME_Version}.zip  assemble/bloomberg
					'''
				}
			}
		}

		stage('Zip the Bloomberg test data'){
			steps{
				script{
					powershell '''
						Compress-Archive -LiteralPath  assemble/bloomberg/source/testdata/autotestdata  bloomberg-testdata.zip
					'''
				}
			}
		}
		
		stage('Resolve base config from artifactory'){
			steps{
				script{
					sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
					sh "jf rt dl ${params.BASE_REPO as String}/Base/nice-aie-${params.BASE_VERSION as String}.zip"
					bat 'ls -ltrh'
				}
			}
		}

		stage('Unzip base config'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  Base/nice-aie-${params.BASE_VERSION as String}.zip  assemble/nice-aie/base
					'''
				}
			}
		}

		stage('Resolve base automation scripts from artifactory'){
			steps{
				script{
					sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
					sh "jf rt dl ${params.BASE_REPO as String}/Base/nice-aie_automation-scripts-${params.BASE_VERSION as String}.zip"
					bat 'ls -ltrh'
				}
			}
		}
		stage('Unzip base automation scripts'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  Base/nice-aie_automation-scripts-${env:BASE_VERSION}.zip  assemble/nice-aie/auto
					'''
				}
			}
		}

		stage('Assemble configuration'){
			steps{
				script{
					powershell '''
							$TARGETDIR="assemble/target"
							$TARGETDIR_NICE_AIE="assemble/target/nice-aie"
							if( -Not (Test-Path -Path $TARGETDIR ) )
							{
								New-Item -ItemType directory -Path $TARGETDIR
							}
							echo --------------------------------------
							echo --------------------------------------
							echo --------------------------------------
							Get-ChildItem -Force "assemble/bloomberg/" -recurse
							echo --------------------------------------
							echo --------------------------------------
							echo --------------------------------------
							Remove-Item -Recurse -Force $TARGETDIR/*
							Copy-Item "assemble/nice-aie/base/*" -Destination $TARGETDIR -force -recurse
							Copy-Item "assemble/nice-aie/auto/*" -Destination $TARGETDIR -force -recurse
							Copy-Item "assemble/bloomberg/*" -Destination $TARGETDIR -force -recurse

							echo List target 
							Get-ChildItem -Force "$TARGETDIR"
							echo --------------------------------------
							echo List target/nice-aie 
							Get-ChildItem -Force "$TARGETDIR_NICE_AIE"
							echo --------------------------------------

							exit $LASTEXITCODE					
						'''
				}
			}
		}

		stage('Clean up target folder from unneccesary files'){
			steps{
				script{
					powershell '''
							$TARGETDIR="assemble/target"
							$TARGETDIR_NICE_AIE="assemble/target/nice-aie"

							if(Test-Path -Path "$TARGETDIR/.git")
							{
								echo "Removing git folder"
								Remove-Item -Recurse -Force $TARGETDIR/.git
							}
							if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes")
							{
								echo "Removing ReleaseNotes file"
								Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes"
							}
							if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes.txt")
							{
								echo "Removing ReleaseNotes.txt file"
								Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes.txt"
							}

							if(Test-Path -Path "$TARGETDIR_NICE_AIE/testdata")
							{
								echo "Removing testdata extra folder"
								Remove-Item -Recurse -Force "$TARGETDIR_NICE_AIE/testdata"
							}

							exit $LASTEXITCODE
						'''
				}
			}
		}

		stage('Post-Compile Clean up target folder from unneccesary files'){
			steps{
				script{
					powershell ''' 
						if( -Not (Test-Path -Path "Bloomberg" ) )
						{
							New-Item -ItemType directory -Path "Bloomberg"
						}
					'''
					}
				}
			}

		stage('Assemble configuration in zip file'){
			steps{
				script{
					powershell '''
						Compress-Archive -LiteralPath  assemble/target  Bloomberg/Bloomberg-WITH-BASE.zip
					'''
				}
			}
		}
		stage('Deploy To Artifactory snapshot-local'){
			steps{
				script{
					sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
					sh "jf rt u **/*.zip  nuget-snapshot-aws-local"
				}
			}
		}

    }
}

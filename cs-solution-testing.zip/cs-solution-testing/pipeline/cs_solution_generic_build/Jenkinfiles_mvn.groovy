import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName

pipeline {

    parameters {
        string(defaultValue: 'test-msbuild', description: 'generic branch for build', name: 'BRANCH_NAME')
        choice(name: 'SLAVE', choices: ['build-agent-fmc-cs-windows', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        booleanParam(name: 'VERACODE_SCAN', defaultValue: 'false', description: 'Whether to scan source code with Veracode')
        string(name: 'RELEASE_VERSION', defaultValue: '', description: 'The version to be released')
        booleanParam(name: 'PERFORM_RELEASE', defaultValue: false, description: 'Whether to execute a Maven release process')
    }
    agent {
        label "${params.SLAVE as String}"
    }


    stages {
        stage('Preparations', {
            steps {
                script {            
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    repoName = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repoName()
                    }
                }
            }
        )

        stage('Maven') {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                        bat 'ls -lthr'
                        String setting_file = "pipeline/cs_solution_generic_build/settings/setting.xml"
                        if (params.PERFORM_RELEASE) {
                            //deploy release
                            // sh "mvn -DdevelopmentVersion=${params.DEVELOPMENT_VERSION} -DreleaseVersion=${params.RELEASE_VERSION} -Dresume=false" +
                            //     " -Prelease release:prepare release:perform -s '${setting_file}'  -Dmaven.repo.local='${WORKSPACE}\\.repository' "
                            sh "git config --global user.name 'gitlab'"
                            sh "git config --global user.email 'gitlab@nice.com'"
                            sh "mvn -B release:branch -DbranchName=release/v${params.RELEASE_VERSION} -DupdateBranchVersions=true -DupdateWorkingCopyVersions=false"
                            sh "mvn -B release:prepare release:perform -DdevelopmentVersion=${params.DEVELOPMENT_VERSION} -DreleaseVersion=${params.RELEASE_VERSION} -Dresume=false -s '${setting_file}'  -Dmaven.repo.local='${WORKSPACE}\\.repository'"
                            //deploy next snapshot
                            // sh "mvn clean deploy -s '${setting_file}' -Dmaven.repo.local='${WORKSPACE}\\.repository'"
                        } else {
                            echo "${WORKSPACE}"
                            echo "${setting_file}"
                            bat "mvn clean deploy -f maven/${repoName}/ -s C:/workspace/FMC/CS/${repoName}/pipeline/cs_solution_generic_build/settings/setting.xml -Dmaven.repo.local=C:/workspace/FMC/CS/${repoName}/build/.repository"
                        }

                    }
                }
            }
        }
    }
}

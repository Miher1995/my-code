static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/ReportingApi.Interface.git' }
static def repoName() { 'ReportingApi.Interface' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/FXT.git' }
static def repoName() { 'FXT' }

return this

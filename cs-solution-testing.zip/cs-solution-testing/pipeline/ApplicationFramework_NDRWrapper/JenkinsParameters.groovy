static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/ApplicationFramework.NDRWrapper.git' }
static def repoName() { 'ApplicationFramework.NDRWrapper' }


return this

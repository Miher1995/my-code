static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ApplicationPlugins.Reconstruction.git' }
static def repoName() { 'Nice.ApplicationPlugins.Reconstruction' }


return this

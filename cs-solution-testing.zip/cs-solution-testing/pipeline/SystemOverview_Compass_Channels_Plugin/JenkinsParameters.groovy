static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sys/SystemOverview.Compass.Channels.Plugin.git' }
static def repoName() { 'SystemOverview.Compass.Channels' }


return this

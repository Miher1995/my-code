static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CyberTech.UserManager.git' }
static def repoName() { 'CyberTech.UserManager' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ApplicationPlugins.Explorer.git' }
static def repoName() { 'Nice.ApplicationPlugins.Explorer' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csms/NiceTradingRecording.Shared.git' }
static def repoName() { 'MediaSources.NTR.Shared' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/CyberTech.MAX.git' }
static def repoName() { 'CyberTech.MAX' }


return this

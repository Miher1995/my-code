static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/JavaScript.TestRunner.git' }
static def repoName() { 'JavaScript.TestRunner' }


return this
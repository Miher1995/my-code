static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/CoreLibraries.RabbitMQ.Clients.git' }
static def repoName() { 'CoreLibraries.RabbitMQ.Clients' }


return this

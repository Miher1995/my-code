static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/applicationframework/ApplicationFramework.Reporting.git' }
static def repoName() { 'ApplicationFramework.Reporting' }
return this
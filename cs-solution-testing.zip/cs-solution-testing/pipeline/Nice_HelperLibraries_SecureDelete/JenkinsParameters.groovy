static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/Nice.HelperLibraries.SecureDelete.git' }
static def repoName() { 'Nice.HelperLibraries.SecureDelete' }


return this

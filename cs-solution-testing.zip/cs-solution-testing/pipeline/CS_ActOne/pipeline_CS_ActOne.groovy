import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '4.5.1', description: 'generic branch for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
      
        
        
       

    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{
        
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )
        stage('Git Checkout  Repository') {
                    steps {
                        script {
                           
                                git(
                                    url: "${repositoryUrl}",
                                    credentialsId: "${git_user}",
                                    branch: "${params.BRANCH_NAME as String}"
                        )
                    
                }
            }
        }

        stage('build'){
			steps{
				script{
					powershell '''echo "${env:Version}"
                   ./build.ps1 -Version "${env:Version}.${env:BUILD_NUMBER}" --verbose  
                    '''	
				}
			}
		}
        stage('Zip the installer'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path  "Installer"  CS-ActOne-${env:Version}.${env:BUILD_NUMBER}.zip   -Update
                            '''
                }
            }
        }
        stage('Git Checkout Default Repository') {
                    steps {
                        script {
                            
                                git(
                                    url: "${repositoryUrl}",
                                    credentialsId: "${git_user}",
                                    branch: "${params.BRANCH_NAME as String}"
                        )
                   
                }
            }
        }
    }
     post{
        success{
                script{
                    archiveArtifacts artifacts: '**/*.zip', allowEmptyArchive: true
                    powershell '''
                        jf rt u **/CS-ActOne*.zip nuget-snapshot-aws-local

                    '''

                }

            }
    }

}

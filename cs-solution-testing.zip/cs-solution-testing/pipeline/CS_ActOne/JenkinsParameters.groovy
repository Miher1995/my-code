static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/CS-ActOne.git' }
static def repoName() { 'CS-ActOne' }

return this
static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/SharedLibraries.Authorization.git' }
static def repoName() { 'SharedLibraries.Authorization' }


return this

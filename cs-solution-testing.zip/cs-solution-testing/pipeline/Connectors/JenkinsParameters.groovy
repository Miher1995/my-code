static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Connectors.git' }
static def repoName() { 'Connectors' }

return this

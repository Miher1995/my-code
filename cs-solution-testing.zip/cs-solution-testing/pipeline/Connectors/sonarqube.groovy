import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: [ 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'version', defaultValue: '4.4.3', description: 'generic branch for build')
        string(name:'project',defaultValue:'FMC_Connectors',description:'project name')
        booleanParam(name: 'SONARQUBE_SCAN', defaultValue: 'true', description: 'Whether to scan with sonarqube')


    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{


            stage('Preparations', {
                steps {
                    script {
                        repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                        }
                    }
                }
            )

            stage('Git Checkout') {
                steps {
                    script {
                            git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                            )
                    }
                }
            }
stage('SonarQube Scan', {
                    steps {
                        script {
                            bat 'ls'
                            dir("maven/Connectors/") {
                                if (params.SONARQUBE_SCAN.toBoolean()) {
                                    print("Starting code scan using SonarQube. sonar.projectName=${project}")
                                    withSonarQubeEnv('SonarQubeITPROD') {
                                        sh "mvn sonar::sonar -Dsonar.projectName=${project}"
                                    }
                                } else {
                                    print("Skipping code scan using SonarQube for sonar.projectName=${project} as parameter params.SONARQUBE_SCAN has value [${params.SONARQUBE_SCAN}]")
                                }
                            }
                        }
                    }
                }) 
stage('SonarQube Quality Gate') {
    when {
        environment name: 'params.SONARQUBE_SCAN', value: 'true'
    }
    steps {
        timeout(time: 10, unit: 'MINUTES') {
            // Parameter indicates whether to set pipeline to UNSTABLE if Quality Gate fails
            // true = set pipeline to UNSTABLE, false = don't
            waitForQualityGate abortPipeline: true
        }
    }
}   



            stage('Update Version'){
                environment {
                    BUILDSYSTEM_HOME="C:\\build-farm\\"
                }

                  steps{
                       script{
                        sh "ls "
                        echo "List of files"
                        powershell '''
						cd solutions/
                        nant   nightly build  -D:CCNetLabel=${env:version}.${env:BUILD_NUMBER} -D:Bamboo= -D:Branch=${env:BRANCH_NAME}

                    '''
                    }
                  }
            }
    }

    post{
        success{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg', allowEmptyArchive: true
                }
            }
    }

}

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/fp/ApplicationPlugins.Fusion.NtrClustersAdministration.git' }
static def repoName() { 'ApplicationPlugins.Fusion.NtrCA' }


return this

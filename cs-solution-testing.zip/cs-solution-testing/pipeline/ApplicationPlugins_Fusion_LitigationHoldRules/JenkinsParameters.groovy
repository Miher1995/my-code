static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/fp/ApplicationPlugins.Fusion.LitigationHoldRules.git' }
static def repoName() { 'AppPlugin.Fusion.LitHoldRules' }


return this

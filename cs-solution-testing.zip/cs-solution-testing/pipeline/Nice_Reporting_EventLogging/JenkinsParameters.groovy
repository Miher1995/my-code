static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/com/Nice.Reporting.EventLogging.git' }
static def repoName() { 'Nice.Reporting.EventLogging' }


return this
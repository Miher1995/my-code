static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/RabbitMQ.git' }
static def repoName() { 'RabbitMQ' }


return this

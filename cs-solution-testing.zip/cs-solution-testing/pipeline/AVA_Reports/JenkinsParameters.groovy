static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/AVA-Reports.git' }
static def repoName() { 'AVA-Reports' }

return this

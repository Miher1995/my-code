import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '1.1.0', description: 'generic branch for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'version', defaultValue: '4.5.1', description: 'inject version')
        
       

    }
    agent {
        label "${params.SLAVE as String}"
    }
    
    stages{
        
        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )
        stage('Git Checkout  Repository') {
                    steps {
                        script {
                                git(
                                    url: "${repositoryUrl}",
                                    credentialsId: "${git_user}",
                                    branch: "${params.BRANCH_NAME as String}"
                        )
                }
            }
        }
        stage('Create branched version', {
            steps{
                script{
                    powershell '''$branchname = "${env:BRANCH_NAME_Version}"
                    $version = "${env:Version}"

                    echo $version

                    if (!($branchname -match "^release"))
                    {
                    $versionlength = [math]::min( 20, $branchname.length )
            
                    $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                    $version = "$version-$branchname"
                    }
                    $version
                    "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII'''

                    powershell '''Get-Content bamboo.variables | Foreach-Object{
                    $var = $_.Split(\'=\')
                    New-Variable -Name $var[0] -Value $var[1]
                    }'''
                }
            }
        })

        stage('Zip the installer'){
                    steps{
                        script{
                            powershell '''
                                Compress-Archive -Path "cs.avareports\\cs\\ava\\source\\" cs.avareports/cs/ava/CSAVAReports-${env:BRANCH_NAME_Version}.zip   -Update
                            '''
                }
            }
        }
        stage('Git Checkout Default Repository') {
                    steps {
                        script {
                            
                                git(
                                    url: "${repositoryUrl}",
                                    credentialsId: "${git_user}",
                                    branch: "${params.BRANCH_NAME as String}"
                        )
                    
                }
            }
        }

        stage('version'){
			steps{
				script{
                    bat 'ls -ltrh'
                    powershell '''
                    cs.avareports/cs/ava/build/version.ps1  cs.avareports/cs/ava/source/tableau/workbooks/ ${env:BRANCH_NAME_Version} ${env:BUILD_NUMBER}
                    '''
					
                   

    }
}
        }

stage('Archive Artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                    sh "jf rt u --flat=true **/*.nupkg  nuget-snapshot-aws-local"

                }
            }
        })




        
    }
}


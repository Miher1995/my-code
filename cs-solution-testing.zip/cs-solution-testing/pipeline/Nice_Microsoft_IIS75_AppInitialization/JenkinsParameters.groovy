static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/nice.microsoft.iis75.appinitialization.git' }
static def repoName() { 'IIS75.AppInitialization' }


return this

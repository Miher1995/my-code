static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csms/NiceTradingRecording.Configuration.git' }
static def repoName() { 'MediaSources.NTR.Configuration' }


return this

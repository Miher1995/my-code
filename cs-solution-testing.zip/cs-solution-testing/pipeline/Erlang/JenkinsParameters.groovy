static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/Erlang.git' }
static def repoName() { 'Erlang' }
return this

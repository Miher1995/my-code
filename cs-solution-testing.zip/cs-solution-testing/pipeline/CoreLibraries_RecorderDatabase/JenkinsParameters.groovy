static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CoreLibraries.RecorderDatabase.git' }
static def repoName() { 'CoreLibraries.RecorderDatabase' }


return this
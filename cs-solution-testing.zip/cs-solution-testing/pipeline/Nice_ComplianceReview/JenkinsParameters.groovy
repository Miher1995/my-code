static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/css/Nice.ComplianceReview.git' }
static def repoName() { 'Nice.ComplianceReview' }


return this

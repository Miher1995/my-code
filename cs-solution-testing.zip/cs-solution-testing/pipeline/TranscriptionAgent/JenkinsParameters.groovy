static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/TranscriptionAgent.git' }
static def repoName() { 'TranscriptionAgent' }


return this

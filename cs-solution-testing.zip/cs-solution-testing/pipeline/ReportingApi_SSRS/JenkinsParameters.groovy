static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cybertech/ReportingApi.SSRS.git' }
static def repoName() { 'ReportingApi.SSRS' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/third-party-wrappers/LibMp3Lame.git' }
static def repoName() { 'LibMp3Lame' }


return this

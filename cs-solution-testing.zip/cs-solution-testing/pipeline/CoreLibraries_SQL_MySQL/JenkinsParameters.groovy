static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/corelibraries/CoreLibraries.SQL.MySQL.git' }
static def repoName() { 'CoreLibraries.SQL.MySQL' }
static def folderName() { 'CoreLibraries.SQL.MySQL.Nuget' }


return this

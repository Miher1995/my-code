static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.ActiveIntelligenceEngine.git' }
static def repoName() { 'Nice.ActiveIntelligenceEngine' }


return this

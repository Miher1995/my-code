static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csp/ApplicationPlugins.RandomSampling.git' }
static def repoName() { 'ApplicationPlugins.RandomSampling' }


return this

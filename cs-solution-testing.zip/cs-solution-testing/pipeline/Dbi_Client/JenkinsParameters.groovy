static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/Dbi-Client.git' }
static def repoName() { 'dbi-client' }


return this
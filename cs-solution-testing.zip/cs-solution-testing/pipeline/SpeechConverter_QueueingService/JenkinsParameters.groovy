static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/SpeechConverter.QueueingService.git' }
static def repoName() { 'SpeechConverter.QueueingService' }


return this

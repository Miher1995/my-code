static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sup/Supervision.UI.git' }
static def repoName() { 'Supervision.UI' }
return this

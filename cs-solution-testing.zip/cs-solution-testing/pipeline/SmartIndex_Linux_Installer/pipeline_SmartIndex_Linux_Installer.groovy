import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '4.3.1', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '4.4.0.35', description: 'generic attivio version for build')
        string( name: 'patch_version', defaultValue: '4.4.0.126', description: 'patch version')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
    }

    agent {
        label "${params.SLAVE as String}"
    }

    stages {
        stage('Preparations', {
				steps {
					script {
						repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
						}
					}
				}
			)


        stage('Git Checkout', {
            steps {
                script {
                    
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                    }
            }
        })


        stage('Resolve attivio binaries', {
                steps{
                    script{

                        sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                        
                        sh "jf rt dl nuget-thirdparty-local/Attivio/${params.attivio_version}/AIE-${params.attivio_version}-lin64.sh installer/"

                        sh "jf rt dl  nuget-thirdparty-local/Attivio/${params.attivio_version}/Patches/aie-patch-${params.patch_version}-common-aieDist.zip installer/"

                        sh "jf rt dl  nuget-thirdparty-local/Attivio/${params.attivio_version}/attivio.license installer/"
                                            }
                }
            })
            stage('Get Script', {
				steps {
					script {
						
						powershell '''Write-Host "list scripts"
                                      Get-ChildItem 

                                      Write-Host "list working dir"

                                      pwd'''
						}
				}
			})
            stage('Assemble the deployment', {
				steps {
					script {
						powershell '''echo ${env:Version}'''
						powershell '''scripts/assembleBuild.ps1 -Version ${env:Version}.${env.BUILD_NUMBER}'''
						}
				}
			})

            stage('Assemble configuration in zip file'){
			steps{
				script{
					powershell '''
						Compress-Archive -Path  "installer\\*"  SmartIndex.installer-${env:Version}.${env.BUILD_NUMBER}.zip -Update
					'''
				}
			}
		}



    }//stages
}

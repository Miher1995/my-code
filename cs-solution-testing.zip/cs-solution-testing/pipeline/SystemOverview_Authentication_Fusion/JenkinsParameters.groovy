static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sys/SystemOverview.Authentication.Fusion.git' }
static def repoName() { 'SystemOverview.Authentication.Fusion' }



return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/apfjobs/ApplicationFramework.Jobs.git' }
static def repoName() { 'ApplicationFramework.Jobs' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CyberTechLibraries.git' }
static def repoName() { 'CyberTechLibraries' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/AVA.Installer.git' }
static def repoName() { 'AVA.Installer' }

return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/auc/UIControls.Html5Player.git' }
static def repoName() { 'Html5Player' }


return this

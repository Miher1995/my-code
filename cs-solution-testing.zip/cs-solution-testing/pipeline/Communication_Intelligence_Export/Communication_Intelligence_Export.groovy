import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: [ 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'version', defaultValue: '4.4.2', description: 'generic branch for build')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{


            stage('Preparations', {
                steps {
                    script {
                        repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                        }
                    }
                }
            )

        stage('checkout', {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                        
                    }
                }
            }
        })
   stage('MSBUILD'){
                environment {
                    BUILDSYSTEM_HOME="C:\\build-farm\\"
                }

                  steps{
                       script{
                        sh "ls "
                        echo "List of files"
                        powershell '''
						cd build/solutions/
                        nant   nightly build  -D:CCNetLabel=${env:version}.${env:BUILD_NUMBER} -D:Bamboo= -D:Branch=${env:BRANCH_NAME}

                    '''
                    }
                  }
            }
    

    
stage('JUNIT Parser configuration'){
    steps{
                       script{
                           bat "mvn clean install -f maven\\export-interactions\\target\\surefire-reports\\*.xml"
                        String setting_file = "${WORKSPACE}/new"
                       }
    }
}
  stage('Deploy NICE modules'){
                environment {
                    BUILDSYSTEM_HOME="C:\\build-farm\\"
                }

                  steps{
                       script{
                        sh "ls "
                        echo "List of files"
                        powershell '''
						
$mvnExe = "$Env:BUILDSYSTEM_HOME" + "tools\\Maven\\3.0.4\\bin\\mvn.bat"

$fixedMvnParams = @(
    "deploy:deploy-file", 
    "-Durl=https://artifactory.actimize.cloud/Temp", 
    "-DgroupId=com.attivio.platform.customers.nice",
    "-Dversion=${bamboo.attivio.branchVersion}")  

$jarPath = Join-Path "${env:BUILD_WORKINGDIRECTORY}" -ChildPath "*.*"
$jarFiles = Get-ChildItem $jarPath -Include *.jar -Exclude *-tests.jar

"Found following jar files:"
$jarFiles

foreach ($jarFile in $jarFiles)
{
    "Processing jar: " + $jarFile.Name
    
    # Match the artifact ID.
    if ($jarFile.Name -match "^(.*)-\\d+\\.\\d+\\.\\d+.*?(-jar-with-dependencies){0,1}.jar$")
    {
        #$Matches[1] will contain the artifact ID, $Matches[2] will contain '-jar-with-dependencies'.
        $artifactId = "{0}{1}" -f $Matches[1], $Matches[2]
        $jarName = $jarFile.Name
        
        $extraMvnParams = @(
            "-DartifactId=$artifactId",
            "-Dfile=$jarName")
    
        "About to execute: $mvnExe $fixedMvnParams $extraMvnParams"
    
        # Execute mvn deploy.
        & $mvnExe $fixedMvnParams $extraMvnParams
        
        if ($LastExitCode -ne 0)
        {
            Exit $LastExitCode
        } 
    }
}

                    '''
                    }
                  }
            }
    
 


    }
    
}
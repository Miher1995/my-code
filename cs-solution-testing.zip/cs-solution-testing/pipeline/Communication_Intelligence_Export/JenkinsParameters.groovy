static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cie/Communication.Intelligence.Export.git' }
static def repoName() { 'Communication.Intelligence.Export' }

return this

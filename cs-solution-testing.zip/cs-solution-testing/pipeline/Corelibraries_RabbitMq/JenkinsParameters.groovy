static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/corelibraries/CoreLibraries.RabbitMQ.git' }
static def repoName() { 'CoreLibraries.RabbitMQ' }


return this


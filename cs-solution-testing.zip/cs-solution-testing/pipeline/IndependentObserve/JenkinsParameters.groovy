static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/IndependentObserve.git' }
static def repoName() { 'IndependentObserve' }


return this

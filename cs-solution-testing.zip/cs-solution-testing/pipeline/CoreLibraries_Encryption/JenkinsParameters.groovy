static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/essentials/CoreLibraries.Encryption.git' }
static def repoName() { 'CoreLibraries.Encryption' }
return this

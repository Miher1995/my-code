static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/TranscriptionAgent.Bootstrapper.git' }
static def repoName() { 'TranscriptionAgent.Bootstrapper' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/auc/UIControls.Explorer.git' }
static def repoName() { 'Explorer' }


return this

static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/ex/Attivio.4.X.git' }
static def repoName() { 'Attivio.4.X' }

return this

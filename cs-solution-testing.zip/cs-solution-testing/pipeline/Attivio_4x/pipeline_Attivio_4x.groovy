import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: [ 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'Version', defaultValue: '2.11.3', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '', description: 'generic attivio version for build')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{

            stage('Download and install AIE 4.4 (if not already installed)'){
                  steps{
                       script{

                        powershell '''

								$existingInstallationPath = "C:\\attivio\\aie_4.4.0"

								if (Test-Path $existingInstallationPath)
								{
									Write-Host "Skipping installation of AIE 4.4.0"
								}
								else
								{
									$url = "https://artifactory.actimize.cloud/artifactory/public-files/AIE-4.4.0.35/"
									$licenseFile = "attivio.license"
									$responseFile = "response.varfile"
									$aieExe = "AIE-4.4.0.35-win64.exe"
									
									$path = "C:\\Temp"
									
									if (!(Test-Path $path))
									{
										New-Item -ItemType Directory -Force -Path $path
									}
									
									$fullLicenseFilePath = Join-Path -Path $path -ChildPath $licenseFile
									$fullResponseFilePath = Join-Path -Path $path -ChildPath $responseFile
									$fullExePath = Join-Path -Path $path -ChildPath $aieExe
									
									"About to download required files"
									
									$wc = New-Object System.Net.WebClient
									$wc.DownloadFile(("{0}{1}" -f $url, $licenseFile), $fullLicenseFilePath)
									$wc.DownloadFile(("{0}{1}" -f $url, $responseFile), $fullResponseFilePath)
									$wc.DownloadFile(("{0}{1}" -f $url, $aieExe), $fullExePath)
									
									"About to execute: & $fullExePath -q -varfile $fullResponseFilePath"
									& $fullExePath -q -varfile $fullResponseFilePath
								}


                        '''
                    }
                }
            }


            stage('Version'){
                  steps{
                       script{

                        powershell '''
                            $branchname = "${env:BRANCH_NAME}"
                            $version = "${env:version}"

                            if (!($branchname -match "^master|release|develop"))
                            {
                                $versionlength = [math]::min( 20, $branchname.length )
                                
                                $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                                $version = "$version-$branchname"
                            }

                            "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII

                    '''
                    }
                }
            }

            stage('Remove local maven repo'){
                  steps{
                       script{

                        powershell '''
						if(Test-Path -Path "$env:USERPROFILE\\.m2")
						{
							echo "Removing m2 folder"
							Remove-Item -Recurse -Force $env:USERPROFILE\\.m2
						}
					

                    '''
                    }
                  }
            }


        stage('Preparations', {
            steps {
                script {
                    repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
                    }
                }
            }
        )


        stage('Git Checkout') {
            steps {
                script {
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                }
            }
        }


		stage('Update Version'){
				steps{
					script{

					powershell '''					
					mvn build-helper:parse-version versions:set -D newVersion=${env:attivio_version} versions:commit
				'''
				}
			}
		}
        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/assemblies/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })
    



    }
}



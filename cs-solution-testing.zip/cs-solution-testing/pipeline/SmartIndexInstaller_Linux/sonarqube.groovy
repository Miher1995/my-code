import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '4.3.1', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '4.4.0.35', description: 'generic attivio version for build')
        string( name: 'patch_version', defaultValue: '4.4.0.126', description: 'patch version')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
        string( name: 'INJECT_VERSION', defaultValue: '4.6.1', description: 'Inject version of automation scripts artifacts')
        string( name: 'PROJECT', defaultValue: 'FMC_SmartIndexInstaller_Linux', description: 'Project name')
        booleanParam(name: 'SONARQUBE_SCAN', defaultValue: 'true', description: 'Whether to scan with SONARQUBE')
    }

    agent {
        label "${params.SLAVE as String}"
    }

    stages {

         stage('set Unix line endings', {
            steps {
                script {                                
                    powershell '''
                    "{env:BUILDSYSTEM_HOME}tools\\git\\portable\\2.8.1\\bin\\git config --global core.autocrlf false"
                    '''
                }
            }
        })

        stage('Preparations', {
				steps {
					script {
						repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
						}
					}
				}
			)


        stage('Git Checkout', {
            steps {
                script {
                    
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                    }
            }
        })
        
stage('SonarQube Scan', {
    steps {
        script {
            dir("build") {
                if (params.SONARQUBE_SCAN.toBoolean()) {
                    print("Starting code scan using SonarQube. sonar.projectName=${PROJECT}")
                    withSonarQubeEnv('actsonarqube01') {
                        sh "mvn sonar::sonar -Dsonar.projectName=${project}"
                    }
                } else {
                    print("Skipping code scan using SonarQube for sonar.projectName=${PROJECT} as parameter params.SONARQUBE_SCAN has value [${params.SONARQUBE_SCAN}]")
                }
            }
        }
    }
})
stage('SonarQube Quality Gate') {
    when {
        environment name: 'params.SONARQUBE_SCAN', value: 'true'
    }
    steps {
        timeout(time: 10, unit: 'MINUTES') {
            // Parameter indicates whether to set pipeline to UNSTABLE if Quality Gate fails
            // true = set pipeline to UNSTABLE, false = don't
            waitForQualityGate abortPipeline: true
        }
    }
}
stage('Assemble the deployment'){
                        steps{
                            script{
                                sh "ls "
                                
                                powershell '''
                                
                                 C:\\workspace\\FMC\\CS\\SmartIndexInstaller_Linux\\scripts\\assembleBuild.ps1 -Version ${env:INJECT_VERSION}.${env:BUILD_NUMBER}
                            
                                '''
                            }
                        }
}

 stage('Restore git line endings'){
    
        steps{
            script{
                powershell '''
                     "{env:BUILDSYSTEM_HOME}tools\\git\\portable\\2.8.1\\bin\\git config --global core.autocrlf true"                  
                                        '''
                            }
                        }
}
    }
}

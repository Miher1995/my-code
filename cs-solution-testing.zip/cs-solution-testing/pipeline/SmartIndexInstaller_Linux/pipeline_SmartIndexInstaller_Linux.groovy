import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '4.3.1', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '4.4.0.35', description: 'generic attivio version for build')
        string( name: 'patch_version', defaultValue: '4.4.0.126', description: 'patch version')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
        string( name: 'INJECT_VERSION', defaultValue: '4.6.1', description: 'Inject version of automation scripts artifacts')
    }

    agent {
        label "${params.SLAVE as String}"
    }

    stages {

         stage('set Unix line endings', {
            steps {
                script {                                
                    powershell '''
                    "{env:BUILDSYSTEM_HOME}tools\\git\\portable\\2.8.1\\bin\\git config --global core.autocrlf false"
                    '''
                }
            }
        })

        stage('Preparations', {
				steps {
					script {
						repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
						}
					}
				}
			)


        stage('Git Checkout', {
            steps {
                script {
                    
                        git(
                            url: "${repositoryUrl}",
                            credentialsId: "${git_user}",
                            branch: "${params.BRANCH_NAME as String}"
                        )
                    }
            }
        })
        

        stage('Assemble the deployment'){
            steps{
                script{
                    sh "ls "
                    
                    powershell '''
                    
                    C:\\workspace\\FMC\\CS\\SmartIndexInstaller_Linux\\scripts\\assembleBuild.ps1 -Version ${env:INJECT_VERSION}.${env:BUILD_NUMBER}
                
                    '''
                }
            }
        }

        stage('artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.zip',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })

        stage('Restore git line endings'){
            
                steps{
                    script{
                        powershell '''
                            "{env:BUILDSYSTEM_HOME}tools\\git\\portable\\2.8.1\\bin\\git config --global core.autocrlf true"                  
                                                '''
                            }
                    }
          
        
    }


stage('Archive Artifacts',{
            steps{
                script{
                    archiveArtifacts artifacts: '**/*.nupkg, **/*.zip, **/*.msi, **/*.exe, TestResult.xml', excludes: 'build/solutions/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                    sh "jf rt u --flat=true **/*.nupkg  nuget-snapshot-aws-local"

                }
            }
        })








}
}

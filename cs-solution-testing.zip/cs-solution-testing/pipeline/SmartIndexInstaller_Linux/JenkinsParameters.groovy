static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/SmartIndexInstaller.Linux.git' }
static def repoName() { 'SmartIndexInstaller.Linux' }


return this

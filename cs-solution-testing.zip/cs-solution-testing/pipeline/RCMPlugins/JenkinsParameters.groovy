static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/csp/RCMPlugins.git' }
static def repoName() { 'RCMPlugins' }

return this

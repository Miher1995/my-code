static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/corelibraries/CoreLibraries.Audio.Utils.git' }
static def repoName() { 'CoreLibraries.Audio.Utils' }


return this
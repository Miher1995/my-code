static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/siip/EmailMailboxFileConnector.git' }
static def repoName() { 'EmailMailboxFileConnector' }

return this
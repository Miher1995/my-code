import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2', 'Gitlab-Jenkins-slave-msbuild-15-VM'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '2.11.3', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '', description: 'generic attivio version for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
			stages{

				stage('Preparations', {
					steps {
						script {
							repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
							}
						}
					}
				)
			stage('Git Checkout') {
					steps {
						script {
							dir("assemble") {
								git(
									url: "${repositoryUrl}",
									credentialsId: "${git_user}",
									branch: "${params.BRANCH_NAME as String}"
								)
							}
						}
					}
			   }
				stage('Prepare connector'){
					steps{
						script{
							powershell '''
										New-Item -ItemType directory -Path "emailMailboxConnector" -Verbose
										if(Test-Path -Path "assemble/.git")
										{
											Write-Host "Removing git folder"
											Remove-Item -Recurse -Force assemble/.git -Verbose
										}
							'''
						}
					}
				}



            stage('branch version', {
                  steps{
                       script{
                            powershell '''
                            $branchname = "${env:BRANCH_NAME_Version}"

                            if (!($branchname -match "^master|release"))
                            {
                                $versionlength = [math]::min( 20, $branchname.length )
                                
                                $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                                $version = "-$branchname"
                            }
                                "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII
                                '''                            
                             }
                       }
                    })
            stage('zip assemble folder content'){
                  steps{
                       script{
                        powershell '''
						echo $branchVersion
                        Compress-Archive -Path  "assemble\\*" emailMailboxConnector/emailMailboxConnector-${env:Version}${branchVersion}.zip  -Update
                        '''
                    }
                }
            }
            stage('Unzip artifact from previous stage'){
			      steps{
				      script{
					        powershell '''
						        Expand-Archive -Path emailMailboxConnector/emailMailboxConnector-${env:Version}${branchVersion}.zip assemble/emailmailboxconnector -Force
					        '''
        				}
		        	}
    		}
            stage('Zip the emailMailboxConnector test data'){
			      steps{
				      script{
					    powershell '''
						Compress-Archive -Path  "assemble\\emailmailboxconnector\\testdata\\autotestdata\\*" emailMailbox-testdata.zip -Update 
    					'''
    				}
	    		}
		    }
            stage('Resolve base config from artifactory'){
			      steps{
				     script{
                        sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                        sh "jf rt dl ${params.BASE_REPO as String}/${params.BASE_FOLDER}/nice-aie-${params.BASE_VERSION as String}.zip"
                        }
                    }
                }
            stage('Unzip base config'){
			steps{
				script{
					powershell '''
                            Expand-Archive -Path  ${env:BASE_FOLDER}/nice-aie-${env:BASE_VERSION}.zip assemble/nice-aie/base -Force
                        '''
                        }
                    }
                }
            stage('Resolve base automation scripts from artifactory'){
                steps{
                    script{
                    sh 'export JFROG_CLI_TRANSITIVE_DOWNLOAD_EXPERIMENTAL=true'
                    sh "jf rt dl nuget-snapshot-aws-local/${params.BASE_FOLDER}/nice-aie_automation-scripts-${params.Version as String}.zip" 
                    }
            }
        }

		stage('Unzip base automation scripts'){
			steps{
				script{
					powershell '''
						Expand-Archive -Path  ${env:BASE_FOLDER}/nice-aie_automation-scripts-${env:BASE_VERSION}.zip  assemble/nice-aie/auto  -Force
					'''
				}
			}
		}


		stage('Assemble configuration'){
			steps{
				script{
					powershell '''
						$TARGETDIR="assemble/target"
						if( -Not (Test-Path -Path $TARGETDIR ) )
						{
						New-Item -ItemType directory -Path $TARGETDIR
						}
						Write-Output "--------------------------------------"
						Get-ChildItem -Force "assemble/emailmailboxconnector/" -recurse
						Write-Output "--------------------------------------"
						Remove-Item -Recurse -Force $TARGETDIR/*
						Copy-Item "assemble/nice-aie/base/*" -Destination $TARGETDIR -force -recurse
						Copy-Item "assemble/nice-aie/auto/*" -Destination $TARGETDIR -force -recurse
						Copy-Item "assemble/emailmailboxconnector/*" -Destination $TARGETDIR -force -recurse

						Write-Output "List $TARGETDIR"
						Get-ChildItem -Force "$TARGETDIR" -Recurse
						Write-Output "--------------------------------------"

						exit $LASTEXITCODE

						'''
				}
			}
		}

		stage('Clean up target folder from unneccesary files'){
			steps{
				script{
					powershell '''
						$TARGETDIR="assemble/target"
						$TARGETDIR_NICE_AIE="assemble/target/nice-aie"


						if(Test-Path -Path "$TARGETDIR/.git")
						{
							echo "Removing git folder"
							Remove-Item -Recurse -Force $TARGETDIR/.git
						}
						if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes")
						{
							echo "Removing ReleaseNotes file"
							Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes"
						}
						if(Test-Path -Path "$TARGETDIR_NICE_AIE/ReleaseNotes.txt")
						{
							echo "Removing ReleaseNotes.txt file"
							Remove-Item -Force "$TARGETDIR_NICE_AIE/ReleaseNotes.txt"
						}

						if(Test-Path -Path "$TARGETDIR_NICE_AIE/testdata")
						{
							echo "Removing testdata extra folder"
							Remove-Item -Recurse -Force "$TARGETDIR_NICE_AIE/testdata"
						}

						exit $LASTEXITCODE

						'''
				}
			}
		}

		stage('Create MSG folder'){
			steps{
				script{
					powershell '''
						if( -Not (Test-Path -Path "emailMailboxConnector" ) )
						{
							New-Item -ItemType directory -Path "emailMailboxConnector"
						}
					'''
					}
				}
			}

		stage('Assemble configuration in zip file'){
			steps{
				script{
					powershell '''
						Compress-Archive -Path  "assemble\\target\\*"  emailMailboxConnector/emailMailboxConnector-WITH-BASE.zip -Update
					'''
				}
			}
		}

   
   
    
	stage('artifacts',{
            steps{
                script{
                    
                    archiveArtifacts artifacts: ' **/*.zip, TestResult.xml', excludes: 'build/solutions/**, build/assemblies/**, build/tests/**, build/deployments/**/*.Example.*',  allowEmptyArchive: true,  onlyIfSuccessful: true
                }
            }
        })
	
	}
}



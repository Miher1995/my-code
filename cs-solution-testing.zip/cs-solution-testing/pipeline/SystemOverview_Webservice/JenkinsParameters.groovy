static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/sys/SystemOverview.Webservice.git' }
static def repoName() { 'SystemOverview.Webservice' }

return this

import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl = 'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/Nice.AppPlugins.FieldConfiguration.git'

pipeline {

    agent {
        label 'build-agent-fmc-cs-windows'
    }


    parameters {
        string(defaultValue: 'master', description: 'generic branch for build', name: 'BRANCH_NAME')
    }

    stages {
        stage('MSBuild', {
            steps {
                script {
                    dir("build") {
                        git(
                                url: "${repositoryUrl}",
                                credentialsId: "${git_user}",
                                branch: "${params.BRANCH_NAME as String}"
                        )
                        String setting_file = "${WORKSPACE}/new"
                            bat "msbuild solutions/Nice.AppPlugins.FieldConfiguration/Nice.AppPlugins.FieldConfiguration.sln"
                    }
                }
            }
        })
    }//stages
}

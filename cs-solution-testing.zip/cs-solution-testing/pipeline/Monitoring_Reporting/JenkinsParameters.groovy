static def repositoryUrl() {'gitlab@tlvgit03.nice.com:fmc-rd/cs/cs/CSMonitoringRepor.git' }
static def repoName() { 'monitoring_report' }

return this

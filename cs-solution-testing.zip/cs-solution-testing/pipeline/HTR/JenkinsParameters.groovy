static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/ex/nice-integration.git' }
static def repoName() { 'nice-integration' }

return this

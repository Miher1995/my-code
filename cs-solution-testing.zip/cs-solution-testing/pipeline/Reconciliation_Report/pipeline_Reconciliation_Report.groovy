import com.actimize.railways.jenkins.shared_libraries.entities.*
import hudson.model.*
import static com.actimize.railways.jenkins.shared_libraries.utils.SendEmailNotification.sendEmailNotification

@Library('shared-libraries@master')


String buildUserEmail = null
String git_user = 'act_fmc_ci_user'
String repositoryUrl
String repoName
String BUILDSYSTEM_HOME


pipeline {


    parameters {
        string( name: 'BRANCH_NAME', defaultValue: 'test-msbuild', description: 'generic branch for build')
        choice( name: 'SLAVE', choices: ['Gitlab-Jenkins-slave-msbuild-15-VM', 'Gitlab-Jenkins-slave-msbuild-15-Build-Farm-VM2'], description: 'Choice the slave')
        string( name: 'BRANCH_NAME_Version', defaultValue: 'jenkins_test', description: 'generic branch for build')
        string( name: 'Version', defaultValue: '2.12.3', description: 'generic branch for build')
		string( name: 'attivio_version', defaultValue: '', description: 'generic attivio version for build')

        string( name: 'BASE_REPO', defaultValue: 'nuget-snapshot-aws-local', description: 'base repo for automation scripts artifacts')
        string( name: 'BASE_VERSION', defaultValue: '4.6.1', description: 'base version of automation scripts artifacts')
        string( name: 'BASE_FOLDER', defaultValue: 'Base', description: 'base version of automation scripts artifacts')
    }

    agent {
        label "${params.SLAVE as String}"
    }
    
		stages{


			stage('Preparations', {
				steps {
					script {
						repositoryUrl = load("pipeline/${env.JOB_BASE_NAME}/JenkinsParameters.groovy").repositoryUrl()
						}
					}
				}
			)


			stage('Git Checkout') {
				steps {
					script {
						dir("reconciliation-${params.BRANCH_NAME}-${BUILD_NUMBER}\\source\\") {
							git(
								url: "${repositoryUrl}",
								credentialsId: "${git_user}",
								branch: "${params.BRANCH_NAME as String}"
							)
						}
					}
				}
			}


            stage('branch version', {
                  steps{
                       script{
                            powershell '''
                            $branchname = "${env:BRANCH_NAME_Version}"

                            if (!($branchname -match "^master|release"))
                            {
                                $versionlength = [math]::min( 20, $branchname.length )
                                
                                $branchname = $branchname.substring(0,$versionlength) -replace "\\/","-"
                                $version = "-$branchname"
                            }
                            "branchVersion=$version" | Out-File ".\\bamboo.variables" -Encoding ASCII
							"env.branchVersion=$version" | Out-File ".\\variables.groovy" -Encoding ASCII
                                '''                            
                             }
                       }
                    })
					
			stage('Inject Variable',{
				steps{
					script{
						myVar = readFile('bamboo.variables').trim()
					}
				}
			})

            stage('zip assemble folder content'){
                  steps{
                       script{

                        powershell '''
						mkdir reconciliation
                        Compress-Archive -Path  "reconciliation-${env:BRANCH_NAME}-${env:BUILD_NUMBER}\\source\\Configuration\\*" reconciliation/reconciliation-reporting-${env:Version}${env:BRANCH_NAME_Version}.zip  -Update
                        '''
                    }
                }
            }

            stage('Zip DB Scripts'){
                  steps{
                       script{

                        powershell '''
                        Compress-Archive -Path   "reconciliation-${env:BRANCH_NAME}-${env:BUILD_NUMBER}\\source\\DBscripts\\*" 	reconciliation/reconciliation-reporting-DBScripts-${env:Version}${env:BRANCH_NAME_Version}.zip  -Update
                        '''
                    }
                }
            }

            stage('Create destination folder'){
                  steps{
                       script{

                        powershell '''

							#creating destination folder
							if(!(Test-Path -Path "reconciliation"))
							{
								Write-Host "Create \"reconciliation\" folder"
								New-Item -ItemType directory -Path "reconciliation"
							}
                        '''
                    }
                }
            }
            stage('Clean checked-out source'){
                  steps{
                       script{

                        powershell '''
							$sourceFolder = "reconciliation-{env:BRANCH_NAME}-${env:BUILD_NUMBER}"
							if(Test-Path -Path $sourceFolder)
							{
								Write-Host "Removing checked-out source folder"
								Remove-Item -Recurse -Force $sourceFolder -Verbose
							}
                        '''
                    }
                }
            }
			stage('artifacts',{
					steps{
						script{
							archiveArtifacts artifacts: 'reconciliation/*.zip'
						}
					}
				})

			stage('Upload artifacts to snapshot-local',{
					steps{
						script{
						sh "  jf rt u --flat=true  'reconciliation/*.zip'  nuget-snapshot-aws-local/reconciliation-reporting/"
						
					}
				}
			})
    }

    post{
        success{
                script{
                    archiveArtifacts artifacts: '**/*.zip', allowEmptyArchive: true
                    powershell '''
                        jf rt u **/*.zip nuget-snapshot-aws-local
                    '''

                }
            }
    }

}



static def repositoryUrl() { 'gitlab@tlvgit03.nice.com:fmc-rd/cs/in/Nice.Microsoft.IISRewrite.Utils.git' }
static def repoName() { 'Nice.Microsoft.IISRewrite.Utils' }

return this
